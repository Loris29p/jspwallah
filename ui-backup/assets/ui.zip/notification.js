window.addEventListener('message', function(event) {
    const event = event.data;

    if (event.type === 'notification') {
        addNotification(event.text, event.color);
    }

});
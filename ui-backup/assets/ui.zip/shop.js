window.addEventListener('message', function(event) {
    const data = event.data;
    if (data.type === 'shop') {
        LoadShop(data);
    }
});



function formatNumberWithCommas(number) {
    if (!number) return 0;
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function LoadShop(data) {
    if (data.bool) {
        console.log("SHOW")
        $(".extinction-body").show();
        $(".extinction-shop").css("display", "flex");
        ChangePages('shop-weapon')
        $(".extinction-shop .shop-box.primary .extinction-title-container .subtitle").text("Tokens: " + data.tokens);
        $(".shop-content-wrapper .shop-content .extinction-shop-item").remove()

        $.each(data.shopsItems, function (k, v) {
            console.log(k)
            const formattedPrice = formatNumberWithCommas(v.price);
            const content = `
            <div class="extinction-shop-item">
            <div class="icon-container">
                <img class="icon" src="./assets/items/${v.name}.png">
            </div>
            <div class="item-data">
                <span class="name">${v.label}</span>
                <span class="category">${v.type}</span>
                <span class="price">${formattedPrice} Tokens</span>
            </div>
            <div class="interaction-buttons">
                <div class="extinction-button secondary" onclick="BuyItem('${v.name}', ${v.price})">
                <span>Buy</span>
                </div>
            </div>
            </div>
            `
            $(".shop-content-wrapper .shop-content").append(content);
        });
    } else {
        $(".extinction-shop").css("display", "none");
        $(".shop-content-wrapper .shop-content .extinction-shop-item").remove();
    }
}


function BuyItem(item, price) {
    $.post('https://gamemode/buyItem', JSON.stringify({
        item: item,
        price: price,
    }));
}   

function SellAll() {
    $.post('https://gamemode/sellAll', JSON.stringify({}));
}
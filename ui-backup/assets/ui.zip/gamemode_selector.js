$(document).on("click", ".extinction-mode-item", function() {
    const gamemodeItem = document.querySelector(".mode-title")
    const gamemodeName = gamemodeItem.textContent

    console.log(gamemodeName, "gamemodeName");

    if (gamemodeName === "1v1 Tricks") {
        $.post("https://gamemode/selectGamemode", JSON.stringify({
            gamemodeItem: gamemodeName
        }));
        $.post("https://gamemode/Close");

        // $(".extinction-mode-selection").fadeOut(300);
    }
});

window.addEventListener("message", function(event) {
    var item = event.data;
    if (item.type === "openGamemodeSelector") {
        console.log("openGamemodeSelector");
        $(".extinction-body").css("display", "flex");
        $(".extinction-mode-selection").css("display", "flex");
        $(".extinction-mode-selection").fadeIn(300);
    }
    if (item.type === "closeGamemodeSelector") {
        console.log("closeGamemodeSelector");
        $(".extinction-body").css("display", "none");
        $(".extinction-mode-selection").css("display", "none");
        $(".extinction-mode-selection").fadeOut(300);
    }
});

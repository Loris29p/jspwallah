window.addEventListener("message", function(event) {
    if (event.data.type == "updateRedzone") {
        console.log("updateRedzone", event.data);
        const redzoneInfo = document.querySelector(".redzone-kill-leader");
        const playerName = document.querySelector(".redzone-kill-leader .main-content .name");
        const killCount = document.querySelector(".redzone-kill-leader .kill-content span");

        if (redzoneInfo.style.display == "none") {
            redzoneInfo.style.display = "";
        }
        
        killCount.textContent = event.data.kills;
        playerName.textContent = event.data.name;
    } else if (event.data.type == "hideRedzoneInfo") {
        const redzoneInfo = document.querySelector(".redzone-kill-leader");
        redzoneInfo.style.display = "none";
    }
});
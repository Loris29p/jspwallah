$(document).ready(function() {
    // Gestion des cases à cocher
    $('input[type="checkbox"]').change(function() {
      const isChecked = $(this).is(':checked');
      const settingName = $(this).closest('.game-option-item').find('.game-option-title').text().trim();
      
      $.post("https://gamemode/SetSetting", JSON.stringify({ setting: settingName, value: isChecked }));
    });
  
    // Gestion des champs de saisie numérique
    $('input[type="number"]').change(function() {
      const inputValue = $(this).val();
      const settingName = $(this).closest('.game-option-item').find('.game-option-title').text().trim();
      
      $.post("https://gamemode/SetSetting", JSON.stringify({ setting: settingName, value: inputValue }));
    });
});


window.addEventListener('message', function(event) {
  const data = event.data;

  if (data.type === 'init') {
      loadSettings();
  }
});

const ListSettings = [
  {name: "hud_life", value: null, label: "Guild Status HUD"},
  {name: "kill_feed", value: null, label: "Kill Feed"},
  {name: "hitmarker", value: null, label: "Hitmarker"},
  {name: "hitmarker_sound", value: null, label: "Hitmarker Sound"},
  {name: "volume_hitmarker", value: 50, label: "Hitmarker Volume"}, 
  {name: "killsound", value: null, label: "Kill Sound"}, 
  {name: "voice_chat", value: null, label: "Voice Chat"},
  {name: "death_voice_chat", value: null, label: "Death Voice Chat"},
];

function loadSettings() {
  $.get("https://gamemode/GetSettings", function(response) {
    console.log(JSON.stringify(response));
    if (response && typeof response === 'object') {
      Object.keys(response).forEach(key => {
        const setting = { name: key, value: response[key] };
        const config = ListSettings.find(item => item.name === setting.name);
        if (config) {
          const titleElement = Array.from(document.querySelectorAll('.game-option-title'))
            .find(el => el.textContent.trim() === config.label);
          if (titleElement) {
            const checkbox = titleElement.closest('.game-option-item').querySelector('input[type="checkbox"]');
            if (checkbox) {
              if (setting.value === true) {
                checkbox.setAttribute('checked', 'checked');
              } else {
                checkbox.removeAttribute('checked');
              }
            }
          }
        }
      });
    } else {
      console.error("Settings is not an object:", response);
    }
  });
}

$(document).ready(function() {
  // Charger les paramètres du joueur
  loadSettings();

  // Gestion des cases à cocher
  $('input[type="checkbox"]').change(function() {
    const isChecked = $(this).is(':checked');
    const settingName = $(this).closest('.game-option-item').find('.game-option-title').text().trim();
    
    $.post("https://gamemode/SetSetting", JSON.stringify({ setting: settingName, value: isChecked }));
  });

  // Gestion des champs de saisie numérique
  $('input[type="number"]').change(function() {
    const inputValue = $(this).val();
    const settingName = $(this).closest('.game-option-item').find('.game-option-title').text().trim();
    
    $.post("https://gamemode/SetSetting", JSON.stringify({ setting: settingName, value: inputValue }));
  });
});
document.addEventListener('DOMContentLoaded', () => {
    function updateDate() {
      const dateElement = document.querySelector('.date');
      if (!dateElement) {
        return;
      }
      
      const now = new Date();
      
      const months = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
      ];
      
      const month = months[now.getMonth()];
      const day = now.getDate();
      const hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      
      const formattedDate = `${month} ${day} - ${hours}:${minutes}`;
      
      dateElement.textContent = formattedDate;
    }
        updateDate();
    
    setInterval(updateDate, 40000);
  });



window.addEventListener('message', function(event) {
    const data = event.data;
    if (data.type === "watermark") {
        $(".watermark-container .identifier").text("Guild PvP - Character " + data.uuid);
        $(".watermark-container .id-temp").text("ID:" + data.id);
    }
});
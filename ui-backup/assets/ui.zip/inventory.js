OtherInventoryType = null
ShiftPressed = false
ControlPressed = false
PlayerMaxWeight = 40
OtherMaxWeight = 25
PlayerWeight = 0
OtherWeight = 0
var combatmode = false;
var DisableInventoryMove = false;


var normalinventoryitem = {};


function formatNumberWithCommas(number) {
  if (!number) return 0;
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}



window.addEventListener('message', function(e) {
    const data = e.data;
    if (data.type == "display") {
        Display(data)
    } else if (data.type == "stats") {
        // console.log(data.playerData.username);
        LoadProfilePlayer(data.playerData);
    } else if (data.type == "leaderboard") {
        SetPodiumLeaderbard(data.podium, "player-killed");
        SetLeaderboard(data.leaderboard, "player-killed");
    }  else if (data.type == "importItemTbl") {
        $.each(data.tbl, function (k, v) {
            normalinventoryitem[k] = v;
        });
        // console.log("All items successfully loaded! [Total Items:" + Object.keys(normalinventoryitem).length + ']');
    } else if (data.type == "hotbar") {
        LoadHotbar(data.hotbar);
    } else if (data.type == "side") {
        DisplaySide(data);
    } else if (data.type == "show-peds") {
        $(".extinction-body").show();
        ChangePages("shop");
        ChangeDonatorPages('myskins')
    } else if (data.type == "updateinventory") {
        LoadInventory(data.inventory);
        LoadSafeInventory(data.safeinventory, "protected");
    } else if (data.type == "updatecombatmode") {
        console.log("COMBATMODE", data.combatmode);
        if (data.combatmode == true) {
          console.log("TRUE")
            combatmode = true;
        } else { 
          console.log("FALSE")
            combatmode = false;
        }
    } else if (data.type == "DisableInventoryMove") {
        DisableInventoryMove = data.movestatus;
    } else if (data.type == "updateWeight") {
      if (data.weights) {
        document.querySelector('#weightProtected .current').textContent = `${data.weights.otherInventoryWeight}kg`;
        document.querySelector('#weightProtected .max').textContent = `${data.weights.maxSafeWeight}kg`;
      
        PlayerMaxWeight = data.weights.maxInvWeight;
        OtherMaxWeight = data.weights.maxSafeWeight;
        PlayerWeight = data.weights.inventoryWeight;
        OtherWeight = data.weights.otherInventoryWeight;

        /* my bag weight */
        document.querySelector('.inventory-container.transparent .weight .current').textContent = `${data.weights.inventoryWeight}kg`;
        document.querySelector('.inventory-container.transparent .weight .max').textContent = `${data.weights.maxInvWeight}kg`;
      }
    }
});

function updateUserInfo(pseudo, uuid, tokens, weightData) {
    document.querySelector('.left-container .name > span:first-child').textContent = pseudo;
    document.querySelector('.left-container .name .color-7').textContent = `(${uuid})`;
    const tokensElement = formatNumberWithCommas(tokens);
    document.querySelector('.left-container .info').textContent = `${tokensElement} Tokens`;

    if (!weightData) return;
    if (!weightData.otherInventoryWeight) return;
    if (!weightData.maxSafeWeight) return;
    if (!weightData.inventoryWeight) return;
    if (!weightData.maxInvWeight) return;
    /* protected weight */
    document.querySelector('#weightProtected .current').textContent = `${weightData.otherInventoryWeight}kg`;
    document.querySelector('#weightProtected .max').textContent = `${weightData.maxSafeWeight}kg`;

    PlayerMaxWeight = weightData.maxInvWeight;
    OtherMaxWeight = weightData.maxSafeWeight;
    PlayerWeight = weightData.inventoryWeight;
    OtherWeight = weightData.otherInventoryWeight;

    /* my bag weight */
    document.querySelector('.inventory-container.transparent .weight .current').textContent = `${weightData.inventoryWeight}kg`;
    document.querySelector('.inventory-container.transparent .weight .max').textContent = `${weightData.maxInvWeight}kg`;

}

LoadHotbar = hotbar => {
  $(".inventory-wrapper.inventory.shortcut > .items-container > .item-slot").remove();
  for (let i = 0; i < 7; i++) {
    const v = hotbar[i];
    const content = `
      <div class="item-slot">
        <span class="details-name">${i + 1}</span>
        <div class="icon-container">
          <img class="icon" ${v && v.name && v.hasItem ? `src="assets/items/${v.name}.png"` : ''}>
        </div>
        <div class="details-container">
          
        </div>
      </div>
    `;
    $(".inventory-wrapper.inventory.shortcut > .items-container").append(content);
  }
}

var DraggingData = null; 
function handleDragDrop() {


  $(".inventory-wrapper.inventory.shortcut > .items-container > .item-slot").droppable({
    hoverClass: 'item-slot-hoverClass',
    drop: function(event, ui) {
      $.post("https://gamemode/SetHotbar", JSON.stringify({ id: $(this).data("id"), itemName: DraggingData["itemName"] }));
    }
  })
}

function FastSlot(name, hang) {
  LastData = {
    'itemName': name,
    'hangi': hang
  };
}

Display = data => {
    if (data.bool) {
        updateUserInfo(data.pseudo, data.uuid, data.tokens, data.inventoryInfo);
        LoadInventory(data.inventory);
        LoadSafeInventory(data.safeinventory, "protected");
        $(".extinction-body").show();
        ChangePages("inventory");
        const element = document.querySelector('.extinction-body');
        if (element) {
            element.style.display = 'flex';
        }
    } else {
        $(".extinction-body").hide();
    }
}

DisplaySide = data => {
  if (data.bool) {
    LoadMyInventorySide(data.inventory, "inventory", data.id);
    if (data.container) {
      LoadContainerBag(data.container, "container", data.id);
    } else {
      LoadContainerBag(data.baginventory, "bag", data.id);
    }
    ChangePages('container');
    $(".extinction-body").show();
    const element = document.querySelector('.extinction-body');
    if (element) {
        element.style.display = 'flex';
    }
  } else {
    $(".extinction-body").hide();
  }
}

function ChangePages(str) {
    if (str == "inventory") {
        $(".inventory-container.transparent").css("display", "flex");
        $(".feedback-view").css("display", "none");
        $(".help-container").css("display", "none");
        $(".extinction-profiles").css("display", "none");
        $(".extinction-leaderboard").css("display", "none");
        $(".gamesettings").css("display", "none");
        $(".inventory-container.side").css("display", "none");
        $(".extinction-donator-shop").css("display", "none");
        $(".extinction-mode-selection").css("display", "none");
        $(".extinction-shop").css("display", "none");
    } else if (str == "gamemode") {
      $(".extinction-body").css("display", "flex");
      $(".inventory-container.transparent").css("display", "none");
      $(".feedback-view").css("display", "none");
      $(".help-container").css("display", "none");
      $(".extinction-profiles").css("display", "none");
      $(".extinction-leaderboard").css("display", "none");
      $(".gamesettings").css("display", "none");
      $(".inventory-container.side").css("display", "none");
      $(".extinction-donator-shop").css("display", "none");
      $(".extinction-shop").css("display", "none");
      $(".extinction-mode-selection").css("display", "flex");
      $(".extinction-mode-selection").fadeIn(300);
    } else if (str == "container") {
        $(".inventory-container.side").css("display", "flex");
        $(".inventory-container.transparent").css("display", "none");
        $(".feedback-view").css("display", "none");
        $(".help-container").css("display", "none");
        $(".extinction-profiles").css("display", "none");
        $(".extinction-leaderboard").css("display", "none");
        $(".gamesettings").css("display", "none");
        $(".extinction-donator-shop").css("display", "none");
        $(".extinction-shop").css("display", "none");
        $(".extinction-mode-selection").css("display", "none");

    } else if (str == "shop-items") {
        $(".inventory-container.side").css("display", "none");
        $(".inventory-container.transparent").css("display", "none");
        $(".feedback-view").css("display", "none");
        $(".help-container").css("display", "none");
        $(".extinction-profiles").css("display", "none");
        $(".extinction-leaderboard").css("display", "none");
        $(".gamesettings").css("display", "none");
        $(".extinction-donator-shop").css("display", "none");
        $(".extinction-shop").css("display", "none");
        $.post("https://gamemode/openShop", JSON.stringify({}));
        $(".extinction-mode-selection").css("display", "none");

    } else if (str == "feedback") {
        $(".inventory-container.transparent").css("display", "none");
        $(".inventory-container.side").css("display", "none");
        $(".feedback-view").fadeIn(1);
        $(".help-container").css("display", "none");
        $(".extinction-profiles").css("display", "none");
        $(".extinction-leaderboard").css("display", "none");
        $(".extinction-donator-shop").css("display", "none");
        $(".extinction-shop").css("display", "none");
        $(".extinction-mode-selection").css("display", "none");

    } else if (str == "help-main") {
        $(".inventory-container.transparent").css("display", "none");
        $(".inventory-container.side").css("display", "none");
        $(".feedback-view").css("display", "none");
        $(".help-container").css("display", "block");
        $(".extinction-profiles").css("display", "none");
        $(".gamesettings").css("display", "none");
        $(".help-container").fadeIn(1); 
        $(".extinction-leaderboard").css("display", "none");
        $(".extinction-donator-shop").css("display", "none");
        $(".extinction-shop").css("display", "none");
        $(".extinction-mode-selection").css("display", "none");

        HelpLoad("tutorial");
    } else if (str == "profile") {
        $(".inventory-container.transparent").css("display", "none");
        $(".inventory-container.side").css("display", "none");
        $(".feedback-view").css("display", "none");
        $(".help-container").css("display", "none");
        $(".gamesettings").css("display", "none");
        $(".extinction-leaderboard").css("display", "none");
        $(".extinction-profiles").css("display", "none");
        $(".extinction-donator-shop").css("display", "none");
        $(".extinction-shop").css("display", "none");
        $(".extinction-profiles").fadeIn(1);
        $(".extinction-mode-selection").css("display", "none");

        LoadProfile2();
    } else if (str == "leaderboard") {
        $(".inventory-container.transparent").css("display", "none");
        $(".inventory-container.side").css("display", "none");
        $(".feedback-view").css("display", "none");
        $(".help-container").css("display", "none");
        $(".extinction-profiles").css("display", "none");
        $(".gamesettings").css("display", "none");
        $(".extinction-leaderboard").css("display", "flex");
        $(".extinction-donator-shop").css("display", "none");
        $(".extinction-leaderboard").fadeIn(1);
        $(".extinction-shop").css("display", "none");
        $(".extinction-mode-selection").css("display", "none");

    } else if (str == "settings") {
      $(".inventory-container.transparent").css("display", "none");
      $(".inventory-container.side").css("display", "none");
      $(".feedback-view").css("display", "none");
      $(".help-container").css("display", "none");
      $(".extinction-profiles").css("display", "none");
      $(".extinction-leaderboard").css("display", "none");
      $(".extinction-donator-shop").css("display", "none");
      $(".gamesettings").css("display", "flex");
      $(".extinction-shop").css("display", "none");
      $(".extinction-mode-selection").css("display", "none");

      $(".gamesettings").fadeIn(1);
    } else if (str == "shop") {
      $(".inventory-container.transparent").css("display", "none");
      $(".inventory-container.side").css("display", "none");
      $(".feedback-view").css("display", "none");
      $(".help-container").css("display", "none");
      $(".extinction-profiles").css("display", "none");
      $(".extinction-leaderboard").css("display", "none");
      $(".gamesettings").css("display", "none");
      $(".extinction-donator-shop").css("display", "flex");
      $(".extinction-shop").css("display", "none");
      $(".extinction-mode-selection").css("display", "none");

      ChangeDonatorPages('rank');
      $(".extinction-donator-shop").fadeIn(1);
    }  else if (str == "shop-weapon") {
      $(".inventory-container.transparent").css("display", "none");
      $(".inventory-container.side").css("display", "none");
      $(".feedback-view").css("display", "none");
      $(".help-container").css("display", "none");
      $(".extinction-profiles").css("display", "none");
      $(".extinction-leaderboard").css("display", "none");
      $(".gamesettings").css("display", "none");
      $(".extinction-donator-shop").css("display", "none");
      $(".extinction-shop").css("display", "flex");
      $(".extinction-mode-selection").css("display", "none");

      $(".extinction-shop").fadeIn(1);
    } else if (str === "market") {
      $(".extinction-body").fadeOut(100);
      $.post("https://gamemode/openMarket", JSON.stringify({}));
    }
}


function togglePrimaryClass(activeId, inactiveId) {
    var activeElement = document.getElementById(activeId);
    var inactiveElement = document.getElementById(inactiveId);
    
    activeElement.classList.add('primary');
    
    inactiveElement.classList.remove('primary');
}

function SetPodiumLeaderbard(data, type) {
    if (type == "player-killed") { 
        $(".leaderboard-podium").empty();
        $.each(data, function(k, v) {
            if (v.avatar == "") {
                v.avatar = "./assets/default-avatar.jpg";
            }
            const content = `
            <div class="extinction-leaderboard-rank-item">
                <div class="game-avatar">
                <img class="image" src="${v.avatar}">
                </div>
                <span class="rank">Top ${k+1}</span>
                <div class="player-info">
                <span class="player-name">
                    <span class="color" style="color: #8b8378"> ${v.username}</span>
                </span>
                <span class="player-crew">
                    <span>None</span>
                </span>
                </div>
                <div class="player-points">
                <span class="points">${v.kills}</span>
                <span class="points-label">Players killed</span>
                </div>
            </div>

            `
            $(".leaderboard-podium").append(content);
        });
    } else if (type == "player-death") {
        $(".leaderboard-podium").empty();
        $.each(data, function(k, v) {
            if (v.avatar == "") {
                v.avatar = "./assets/default-avatar.jpg";
            }
            const content = `
            <div class="extinction-leaderboard-rank-item">
                <div class="game-avatar">
                <img class="image" src="${v.avatar}">
                </div>
                <span class="rank">Top ${k+1}</span>
                <div class="player-info">
                <span class="player-name">
                    <span class="color" style="color: #8b8378"> ${v.username}</span>
                </span>
                <span class="player-crew">
                    <span>None</span>
                </span>
                </div>
                <div class="player-points">
                <span class="points">${v.death}</span>
                <span class="points-label">Death</span>
                </div>
            </div>
            `
            $(".leaderboard-podium").append(content);
        });
    } else if (type == "player-token") {
        $(".leaderboard-podium").empty();
        $.each(data, function(k, v) {
            if (v.avatar == "") {
                v.avatar = "./assets/default-avatar.jpg";
            }
            const tokenVARIABLE = formatNumberWithCommas(v.token);
            const content = `
            <div class="extinction-leaderboard-rank-item">
                <div class="game-avatar">
                <img class="image" src="${v.avatar}">
                </div>
                <span class="rank">Top ${k+1}</span>
                <div class="player-info">
                <span class="player-name">
                    <span class="color" style="color: #8b8378"> ${v.username}</span>
                </span>
                <span class="player-crew">
                    <span>None</span>
                </span>
                </div>
                <div class="player-points">
                <span class="points">${tokenVARIABLE}</span>
                <span class="points-label">Guild Token</span>
                </div>
            </div>
            `
            $(".leaderboard-podium").append(content);
        });
    }
}


function SetLeaderboard(data, type) {
    var tbody = document.querySelector('.extinction-table tbody');
            
    if (tbody) {
        tbody.innerHTML = '';
    }
    // outpout : [{"avatar":"","kills":0,"username":"E-SIM SPAM LA NL"}] (@gamemode/ui/assets/inventory.js:177) 
    if (type == "player-killed") {
        $.each(data, function(k, v) {
            const content = `
            <tr>
                <td class="rank-column">#${k + 1}</td>
                <td class="name-column">
                    <div style="display: flex; flex-direction: row;">
                    <div class="game-badge leaderboard-badge">
                        <img alt="" ${v && v.prestige > 0 ? `src="/ui/assets/badges/prestige_${v.prestige}.png"` : ''}>
                    </div>
                    <span class="leaderboard-name">
                        <span class="color" style="color: #8b8378"> ${v.username}</span>
                    </span>
                    </div>
                </td>
                <td class="total-column">${v.kills}</td>
                <td class="right-cell" style="text-align: right; padding-right: 3vh;">${v.country}</td>
                </tr>
            `
            $(".extinction-table tbody").append(content);
        });
    } else if (type == "player-death") {
        $.each(data, function(k, v) {
            const content = `
            <tr>
                                <td class="rank-column">#${k + 1}</td>
                                <td class="name-column">
                                  <div style="display: flex; flex-direction: row;">
                                    <div class="game-badge leaderboard-badge">
                                      <img alt="" ${v && v.prestige > 0 ? `src="/ui/assets/badges/prestige_${v.prestige}.png"` : ''}>
                                    </div>
                                    <span class="leaderboard-name">
                                      <span class="color" style="color: #8b8378"> ${v.username}</span>
                                    </span>
                                  </div>
                                </td>
                                <td class="total-column">${v.death}</td>
                                <td class="right-cell" style="text-align: right; padding-right: 3vh;">${v.country}</td>
                              </tr>
            `
            $(".extinction-table tbody").append(content);
        });

    } else if (type == "player-token") {
        $.each(data, function(k, v) {
          const tokenVARIABLE = formatNumberWithCommas(v.token);
            const content = `
            <tr>
                                <td class="rank-column">#${k + 1}</td>
                                <td class="name-column">
                                  <div style="display: flex; flex-direction: row;">
                                    <div class="game-badge leaderboard-badge">
                                      <img alt="" ${v && v.prestige > 0 ? `src="/ui/assets/badges/prestige_${v.prestige}.png"` : ''}>
                                    </div>
                                    <span class="leaderboard-name">
                                      <span class="color" style="color: #8b8378"> ${v.username}</span>
                                    </span>
                                  </div>
                                </td>
                                <td class="total-column">${tokenVARIABLE}</td>
                                <td class="right-cell" style="text-align: right; padding-right: 3vh;">${v.country}</td>
                              </tr>
            `
            $(".extinction-table tbody").append(content);
        });
    }
}

function LoadProfile2() {
  $.post("https://gamemode/GetPlayerStats", JSON.stringify({}));
}


function LoadProfilePlayer(data) {
    $(".extinction-profiles").empty();  
    const tokenVARIABLE = formatNumberWithCommas(data.tokens);
    const content = `
    <div class="extinction-player-profile">
                      <div class="profile-box summary">
                        <div class="extinction-title-container">
                          <div class="top-container">
                            <span class="title">
                              <span>Player's profile</span>
                            </span>
                          </div>
                          <span class="subtitle">Overview</span>
                        </div>
                        <div class="profile-box-content">
                          
                          
                          <div class="summary">
                            <div class="info-items">
                              <span class="title">
                                <span>${data.username}</span>
                              </span>
                              <span class="subtitle">Nickname</span>
                              <div class="extinction-button">
                                <span>Infos prestige</span>
                              </div>
                            </div>
                            <div class="info-items">
                              <span class="title" style="cursor: pointer;">${data.crewName}</span>
                              <span class="subtitle">Crew</span>
                              <div class="extinction-button yellow-title">
                                <span>Shop prestige</span>
                              </div>
                            </div>
                            <div class="info-items">
                              <span class="title">${data.country}</span>
                              <span class="subtitle">Country</span>
                            </div>
                            <div class="info-items">
                              <span class="title">0</span>
                              <span class="subtitle">Prestige</span>
                            </div>
                            <div class="info-items right">
                              <div class="column">
                                <span class="title">${tokenVARIABLE}</span>
                                <span class="subtitle">Tokens</span>
                              </div>
                              <div class="column">
                                <span class="title">${data.coins}</span>
                                <span class="subtitle">Coins Guild</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="profile-box stats">
                        <div class="extinction-title-container">
                          <div class="top-container">
                            <span class="title">
                              <span>Stats character</span>
                            </span>
                            <div class="right-components"></div>
                          </div>
                          <span class="subtitle">Overview of your ranks and statistics</span>
                        </div>
                        <div class="extinction-stats-table profile-box-content column">
                          <div class="stats-container-buttons">
                            <div class="extinction-button selected">
                              <span>Global Stats</span>
                            </div>
                          </div>
                          <div class="stats-container-data">
                            <div class="stats-item">
                              <span class="value">${data.kd}</span>
                              <span class="title">KD/A</span>
                            </div>
                            <div class="stats-item">
                              <span class="value">${data.kills}</span>
                              <span class="title">Players killed</span>
                            </div>
                            <div class="stats-item">
                              <span class="value">${data.death}</span>
                              <span class="title">Death</span>
                            </div>
                            <div class="stats-item">
                              <span class="value">${tokenVARIABLE}</span>
                              <span class="title">Tokens Guild</span>
                            </div>
                          </div>
                          <div class="stats-container-rank">
                            <span class="rank">Non classé</span>
                            <span class="rank">${data.placeKill}</span>
                            <span class="rank">${data.placeDeath}</span>
                            <span class="rank">${data.placeToken}</span>
                          </div>
                        </div>
                      </div>
                      <div class="profile-box">
                        <div class="extinction-title-container">
                          <div class="top-container">
                            <span class="title">
                              <span>Badges</span>
                            </span>
                            <div class="right-components"></div>
                          </div>
                          <span class="subtitle">Badges collected</span>
                        </div>
                        <div class="profile-box-content badges empty">
                          <span class="empty-title>">no-badges</span>
                        </div>
                      </div>
                      <div class="profile-box perks">
                        <div class="extinction-title-container">
                          <div class="top-container">
                            <span class="title">
                              <span>Advantages</span>
                            </span>
                            <div class="right-components"></div>
                          </div>
                          <span class="subtitle">Prestige advantages</span>
                        </div>
                        <div class="profile-box-content bordered grid-5">
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">Drone Weight</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">+0kg</span>
                            </div>
                          </div>
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">Zombie damage</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">+0%</span>
                            </div>
                          </div>
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">Marketplace offers</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">0</span>
                            </div>
                          </div>
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">Character speed</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">+0%</span>
                            </div>
                          </div>
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">Antizin time</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">0</span>
                            </div>
                          </div>
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">Inventory Weight</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">+0kg</span>
                            </div>
                          </div>
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">Container Weight</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">+0kg</span>
                            </div>
                          </div>
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">Drone time</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">+0%</span>
                            </div>
                          </div>
                          <div class="info-items row center">
                            <div class="perk-item">
                              <span class="title">FleshShot time</span>
                              <span class="subtitle">Étape 0</span>
                            </div>
                            <div class="perk-item">
                              <span class="title gold">0</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="extinction-glife-profile" style="display: none;">
                      <div class="profile-box summary">
                        <div class="extinction-title-container">
                          <div class="top-container">
                            <span class="title">
                              <span>Profil</span>
                            </span>
                          </div>
                          <span class="subtitle">Résumé de votre compte</span>
                        </div>
                        <div class="profile-box-content">
                          <div class="profile-round-info-box">
                            <img class="avatar" src="./assets/default_avatar.jpg">
                          </div>
                          <div class="summary column">
                            <div class="row-items">
                              <div class="info-items">
                                <span class="title">No FiveM account Linked</span>
                                <span class="subtitle">Nom du compte</span>
                              </div>
                              <div class="info-items">
                                <span class="title">0</span>
                                <span class="subtitle">id</span>
                              </div>
                              <div class="info-items right">
                                <span class="title red">0</span>
                                <span class="subtitle">GCoins</span>
                              </div>
                            </div>
                            <div class="row-items bottom">
                              <div class="extinction-button" style="margin-right: 1vh;">
                                <span>Synchroniser les boosters</span>
                              </div>
                              <div class="info-items right">
                                <div class="extinction-button primary">
                                  <span>Obtenir des GCoins</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="profile-box transaction">
                        <div class="extinction-title-container">
                          <div class="top-container">
                            <span class="title">
                              <span>transactions</span>
                            </span>
                            <div class="right-components"></div>
                          </div>
                          <span class="subtitle">Transactions Tebex</span>
                        </div>
                        <div class="profile-box-content">
                          <div class="transactions empty">
                            <span class="empty-title>">Vous n'avez pas de transactions.</span>
                          </div>
                        </div>
                      </div>
                      <div class="profile-box boosters">
                        <div class="extinction-title-container">
                          <div class="top-container">
                            <span class="title">
                              <span>Booster</span>
                            </span>
                            <div class="right-components"></div>
                          </div>
                          <span class="subtitle">Boosters disponibles</span>
                        </div>
                        <div class="profile-box-content boosters empty">
                          <span class="empty-title>">Vous n'avez pas de boosters.</span>
                        </div>
                      </div>
                    </div>
    
    `;
    $(".extinction-profiles").append(content);
}


function HelpLoad(str) {
    if (str == "tutorial") {
        togglePrimaryClass('tutorial-button', 'commands-button');
        $(".help-page-container").empty();
    
        const content = `
        <div class="help-page no-background">
                        <div class="article">
                          <p class="title big">Beginner guide</p>
                          <p class="credits">Server made by players for players.</p>
                          <p class="title">What is Guild PvP</p>
                          <p>Guild PvP is a unique FiveM server crafted specifically for PvP enthusiasts. Built on feedback from experienced players, this server offers an extraordinary experience where every aspect is tailored for those who love tricks and intense combat.</p>
                          <p>The gaming environment, optimized to perfection, captures the electric atmosphere of FiveM Prime 2020/2021,</p>
                          <span class="" style="display: inline-block;"></span>
                          <p>with smooth graphics and flawless gameplay. Guild PvP stands out with its dedicated community and constant focus on providing a balanced and competitive battlefield, making every fight unforgettable.</p>
                          <p>Whether you're a PvP veteran or a newcomer looking to improve, this server promises hours of thrilling challenges.</p>
                        </div>
                        <div class="media">
                          <p class="title big">Helpful videos</p>
                          <div class="video-list">
                            <div class="video-row">
                              <div class="video-item">
                                <div class="iframe-top">
                                  <iframe src="https://www.youtube.com/embed/VfFcIR5phAI?si=p5-g0x0URCJUU3mx"></iframe>
                                </div>
                                <span class="description">Best of RyWaZ</span>
                              </div>
                              <div class="video-item">
                                <div class="iframe-top">
                                  <iframe src="https://www.youtube.com/embed/dCyCk6KP4Ds?si=jEbDb81qoUSKbKJc"></iframe>
                                </div>
                                <span class="description">Best of kaykL</span>
                              </div>
                              <div class="video-item">
                                <div class="iframe-top">
                                  <iframe src="https://www.youtube.com/embed/Bo-u6g4Biy4?si=XXmDFxmF9uu-OZnA"></iframe>
                                </div>
                                <span class="description">Best of kaykL 2</span>
                              </div>
                            </div>
                            <div class="video-row">
                              <div class="video-item">
                                <div class="iframe-top">
                                  <iframe src="https://www.youtube.com/embed/Ltztmb1TEho?si=y5yDSSZB-H1eXPT4"></iframe>
                                </div>
                                <span class="description">Best of MaSon</span>
                              </div>
                              <div class="video-item"></div>
                              <div class="video-item"></div>
                            </div>
                            <div class="video-row">
                              <div class="video-item invisible"></div>
                            </div>
                            <span class="disclaimer">Want you video here? Contact the support with your tutorial!</span>
                          </div>
                        </div>
                      </div>
        `
        $(".help-page-container").append(content);

    } else if (str == "commands") {
        togglePrimaryClass('commands-button', 'tutorial-button');
        $(".help-page-container").empty();
        
        const content = `
        <div class="help-page column scroll">
      <div class="command-list">
        <span class="title">Global commands</span>
        <div class="commands">
          <span>/time - Display your total play time this season.</span>
          <span>/prestige - Display information about the prestige system</span>
          <span>/setprestige - Get new prestige and reset your rank if you're eligle for it</span>
          <span>/createcrew - Create a crew</span>
          <span>/crew - Open the crew menu</span>
          <span>/leavecrew - Leave your current crew</span>
          <span>/disband - Delete your crew if you are the leader</span>
          <span>/stuck - Unstuck yourself</span>
          <span>/bounty - Open the bounty menu</span>
          <span>/booster - Display your boosters</span>
          <span>/supporter - Get your supporter purchases like boosters</span>
          <span>/getrank - Get your shop rank</span>
          <span>/selfresethead - Reset your appearance</span>
          <span>/nickname - Change your nickname</span>
          <span>/dungeon - Display the dungeon commands help</span>
          <span>/squad - Display the squad commands help</span>
          <span>/trade [characterId] - Trade with another player</span>
          <span>/kit - Display your available kits</span>
        </div>
        </div>
        <div class="command-list">
            <span class="title">Gold commands</span>
            <div class="commands">
            <span>/kit gold - To get your gold kit</span>
            <span>/deathmessage - To set your death messag</span>
            </div>
        </div>
        <div class="command-list">
            <span class="title">Diamond commands</span>
            <div class="commands">
            <span>/effect - To set your kill effect</span>
            <span>/kit diamond = To get your diamond kit</span>
            <span>/reset_stats - Reset all your statistics</span>
            <span>/fw - Spawn a firework</span>
            <span>/morphmode - Open the morph mode menu</span>
            <span>/screen - Open the safezone screen menu</span>
            </div>
        </div>
        </div>
        `
        $(".help-page-container").append(content);
    }
}

LoadInventory = inventory => {
  $(".inventory-wrapper.inventory.self > .items-container > .item-slot").remove();
  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;
  
  $.each(inventory, function(k, v) {
      const isSmallScreen = screenWidth <= 1600 && screenHeight <= 1400;
      const widthStyle = isSmallScreen ? 'style="width: 11.5vh;"' : '';
      
      const content = `
          <div class="item-slot" id="item-slot-${v.name}" onclick="FastMove('${v.name}')" onmouseenter="FastSlot('${v.name}', 'normal')" data-itemdata='${JSON.stringify({itemName: v.name, itemCount: v.count, currentContainer: "inventory"})}'>
              <span class="details-name" id="normal-count-${v.name}">x${v.count}</span>
              <div class="icon-container">
                  <img class="icon" src="assets/items/${v.name}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''} background-repeat: no-repeat; pointer-events: none; background-position: center; background-size: cover;">
              </div>
              <div class="details-container">
                  <span class="item-name">${v.label}</span>
              </div>
          </div>
      `;

      $(".inventory-wrapper.inventory.self > .items-container").append(content);
      $("#item-slot-" + v.name).data("item", v.name);
      $("#item-slot-" + v.name).data("count", v.count);
  });
};


LoadSafeInventory = (inventory, inventoryType) => {
  $(".inventory-wrapper.inventory.safe > .items-container > .item-slot").remove();
  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;

  $.each(inventory, function(k, v) {
      const isSmallScreen = screenWidth <= 1600 && screenHeight <= 1400;
      const widthStyle = isSmallScreen ? 'style="width: 11.5vh;"' : '';

      const content = `
          <div class="item-slot" id="safe-item-slot-${v.name}" onclick="FastMove('${v.name}')" onmouseenter="FastSlot('${v.name}', 'safe')" data-itemdata='${JSON.stringify({itemName: v.name, itemCount: v.count, currentContainer: inventoryType})}'>
              <span class="details-name" id="safe-count-${v.name}">x${v.count}</span>
              <div class="icon-container">
                  <img class="icon" src="assets/items/${v.name}.png" alt="${v.label}" ${isSmallScreen ? 'style="width: 157%; height: 90%;"' : ''}>
              </div>
              <div class="details-container">
                  <span class="item-name">${v.label}</span>
              </div>
          </div>
      `;

      $(".inventory-wrapper.inventory.safe > .items-container").append(content);
      $(`#safe-item-slot-${v.name}`).data("item", v.name);
      $(`#safe-item-slot-${v.name}`).data("count", v.count);
  });
};




// if (/^bags-\d+$/.test(id)) {
//   $(".inventory-wrapper.inventory.half.side .extinction-title-container .top-container .title span").text("Bags");
// } else if (/^stash-\d+$/.test(id)) {
//   $(".inventory-wrapper.inventory.half.side .extinction-title-container .top-container .title span").text("Stash");
// }

LoadMyInventorySide = (inventory, inventoryType, id) => {
  $(".inventory-wrapper.inventory.half.side > .items-container.side > .item-slot").remove();
  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;
  
  $.each(inventory, function(k, v) {
    const isSmallScreen = screenWidth <= 1600 && screenHeight <= 1400;
    const widthStyle = isSmallScreen ? 'style="width: 11.5vh;"' : '';
    
    const content = `
      <div class="item-slot" id="inv-item-slot-${v.name}" onclick="FastMoveContainer('${v.name}', '${id}')" onmouseenter="FastSlot('${v.name}', 'normal')" data-itemdata='${JSON.stringify({itemName: v.name, itemCount: v.count, currentContainer: inventoryType, id: id})}'>
        <span class="details-name" id="inv-count-${v.name}">x${v.count}</span>
        <div class="icon-container">
          <img class="icon" src="assets/items/${v.name}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''} background-repeat: no-repeat; pointer-events: none; background-position: center; background-size: cover;">
        </div>
        <div class="details-container">
          <span class="item-name">${v.label}</span>
        </div>
      </div>
    `;

    $(".inventory-wrapper.inventory.half.side > .items-container.side").append(content);
    $("#inv-item-slot-" + v.name).data("item", v.name);
    $("#inv-item-slot-" + v.name).data("count", v.count);
    $("#inv-item-slot-" + v.name).data("id", id);
  });
};


LoadContainerBag = (inventory, inventoryType, id) => {
  $(".inventory-wrapper.inventory.side:not(.half) > .items-container.side > .item-slot").remove();
  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;

  $.each(inventory, function(k, v) {
    const isSmallScreen = screenWidth <= 1600 && screenHeight <= 1400;
    const widthStyle = isSmallScreen ? 'style="width: 11.5vh;"' : '';

    const content = `
      <div class="item-slot" id="container-item-slot-${v.name}" onclick="FastMoveContainer('${v.name}', '${id}')" onmouseenter="FastSlot('${v.name}', 'container')" data-itemdata='${JSON.stringify({itemName: v.name, itemCount: v.count, currentContainer: inventoryType, id: id})}'>
        <span class="details-name" id="container-count-${v.name}">x${v.count}</span>
        <div class="icon-container">
          <img class="icon" src="assets/items/${v.name}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''} background-repeat: no-repeat; pointer-events: none; background-position: center; background-size: cover;">
        </div>
        <div class="details-container">
          <span class="item-name">${v.label}</span>
        </div>
      </div>
    `;

    $(".inventory-wrapper.inventory.side:not(.half) > .items-container.side").append(content);
    $("#container-item-slot-" + v.name).data("item", v.name);
    $("#container-item-slot-" + v.name).data("count", v.count);
    $("#container-item-slot-" + v.name).data("id", id);
  });
};


function FastMoveContainer(itemName, id) {
  itemid = itemName;
  id = id;
  which = LastData.hangi;

  if (DisableInventoryMove == true) {
    return;
  }

  if (typeof which == 'undefined' || which == null) {
    return;
  }

  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;
  const isSmallScreen = screenWidth <= 1600 && screenHeight <= 1400;

  if (which == 'normal') {
    if (combatmode == true) {
      return;
    }
    safecount = $("#inv-item-slot-" + itemid).data("count");
    if (safecount > 1) {
      x = safecount - 1;
      check = document.getElementById("inv-count-" + itemid).innerHTML = 'x' + x;
      if (typeof check === "undefined" || check === null) {
        return;
      }
      $("#inv-item-slot-" + itemid).data("count", x);
      if ($("#container-item-slot-" + itemid).length > 0) {
        safecount = $('#container-item-slot-' + itemid).data("count");
        updatesafecount = safecount + 1;
        $("#container-item-slot-" + itemid).data("count", updatesafecount);
        $("#container-item-slot-" + itemid).data('item', itemid);
        document.getElementById("container-count-" + itemid).innerHTML = 'x' + updatesafecount;
        $.post("https://gamemode/CheckContainer", JSON.stringify({
          'item': itemid,
          'id': id
        }), function(_0x2ed332) {});
      } else {
        const content = `
          <div class="item-slot" id="container-item-slot-${itemid}" onclick="FastMoveContainer('${itemid}', '${id}')" onmouseenter="FastSlot('${itemid}', 'container')" data-itemdata=${JSON.stringify({itemName: itemid, itemCount: 1, currentContainer: "container", id: id})}>
            <span class="details-name" id="container-count-${itemid}">x1</span>
            <div class="icon-container">
              <img class="icon" src="assets/items/${itemid}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''}">
            </div>
            <div class="details-container">
              <span class="item-name">${normalinventoryitem[itemid].label}</span>
            </div>
          </div>
        `;
        $(".inventory-wrapper.inventory.side:not(.half) > .items-container.side").append(content);
        $("#container-item-slot-" + itemid).data("item", itemid);
        $("#container-item-slot-" + itemid).data("count", 1);
        $("#container-item-slot-" + itemid).data("id", id);
        $.post("https://gamemode/CheckContainer", JSON.stringify({
          'item': itemid,
          'id': id
        }), function(_0x5c8bee) {});
      }
    } else {
      if ($("#container-item-slot-" + itemid).length > 0) {
        safecount = $('#container-item-slot-' + itemid).data("count");
        updatesafecount = safecount + 1;
        $("#container-item-slot-" + itemid).data("count", updatesafecount);
        $("#container-item-slot-" + itemid).data('item', itemid);
        document.getElementById("container-count-" + itemid).innerHTML = 'x' + updatesafecount;
      } else {
        const content = ` 
          <div class="item-slot" id="container-item-slot-${itemid}" onclick="FastMoveContainer('${itemid}', '${id}')" onmouseenter="FastSlot('${itemid}', 'container')" data-itemdata=${JSON.stringify({itemName: itemid, itemCount: 1, currentContainer: "container", id: id})}>
            <span class="details-name" id="container-count-${itemid}">x1</span>
            <div class="icon-container">
              <img class="icon" src="assets/items/${itemid}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''}">
            </div>
            <div class="details-container">
              <span class="item-name">${normalinventoryitem[itemid].label}</span>
            </div>
          </div>
        `;
        $(".inventory-wrapper.inventory.side:not(.half) > .items-container.side").append(content);
        $("#container-item-slot-" + itemid).data("item", itemid);
        $("#container-item-slot-" + itemid).data("count", 1);
        $("#container-item-slot-" + itemid).data("id", id);
      }
      $("#inv-item-slot-" + itemid).remove();
      $.post("https://gamemode/CheckContainer", JSON.stringify({
        'item': itemid,
        'id': id
      }), function(_0xa0444a) {});
    }
  } else {
    if (PlayerWeight + normalinventoryitem[itemid].weight > PlayerMaxWeight) {
      return;
    }

    safecount = $("#container-item-slot-" + itemid).data("count");
    if (safecount > 1) {
      x = safecount - 1;
      check = document.getElementById("container-count-" + itemid).innerHTML = 'x' + x;
      if (typeof check === "undefined" || check === null) {
        return;
      }
      $("#container-item-slot-" + itemid).data("count", x);
      if ($("#inv-item-slot-" + itemid).length > 0) {
        f = $('#inv-item-slot-' + itemid).data("count");
        c = f + 1;
        $("#inv-item-slot-" + itemid).data("item", itemid);
        $("#inv-item-slot-" + itemid).data("count", c);
        document.getElementById("inv-count-" + itemid).innerHTML = 'x' + c;
        $.post("https://gamemode/CheckContainer2", JSON.stringify({
          'item': itemid,
          'id': id
        }), function(_0x2ed332) {});
      } else {
        const content = `
          <div class="item-slot" id="inv-item-slot-${itemid}" onclick="FastMoveContainer('${itemid}', '${id}')" onmouseenter="FastSlot('${itemid}', 'normal')" data-itemdata=${JSON.stringify({itemName: itemid, itemCount: 1, currentContainer: "inventory", id: id})}>
            <span class="details-name" id="inv-count-${itemid}">x1</span>
            <div class="icon-container">
              <img class="icon" src="assets/items/${itemid}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''}">
            </div>
            <div class="details-container">
              <span class="item-name">${normalinventoryitem[itemid].label}</span>
            </div>
          </div>
        `;
        $(".inventory-wrapper.inventory.half.side > .items-container.side").append(content);
        $("#inv-item-slot-" + itemid).data("item", itemid);
        $("#inv-item-slot-" + itemid).data("count", 1);
        $("#inv-item-slot-" + itemid).data("id", id);
        $.post("https://gamemode/CheckContainer2", JSON.stringify({
          'item': itemid,
          'id': id
        }), function(_0x5c8bee) {});
      }
    } else {
      if ($("#inv-item-slot-" + itemid).length > 0) {
        za = $('#inv-item-slot-' + itemid).data("count");
        updatesafecount = za + 1;
        $("#inv-item-slot-" + itemid).data("item", itemid);
        $("#inv-item-slot-" + itemid).data("count", updatesafecount);
        document.getElementById("inv-count-" + itemid).innerHTML = 'x' + updatesafecount;
      } else {
        const content = `
          <div class="item-slot" id="inv-item-slot-${itemid}" onclick="FastMoveContainer('${itemid}', '${id}')" onmouseenter="FastSlot('${itemid}', 'normal')" data-itemdata=${JSON.stringify({itemName: itemid, itemCount: 1, currentContainer: "inventory", id: id})}>
            <span class="details-name" id="inv-count-${itemid}">x1</span>
            <div class="icon-container">
              <img class="icon" src="assets/items/${itemid}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''}">
            </div>
            <div class="details-container">
              <span class="item-name">${normalinventoryitem[itemid].label}</span>
            </div>
          </div>
        `;
        $(".inventory-wrapper.inventory.half.side > .items-container.side").append(content);
        $("#inv-item-slot-" + itemid).data("item", itemid);
        $("#inv-item-slot-" + itemid).data("count", 1);
      }
      $("#container-item-slot-" + itemid).remove();
      $.post("https://gamemode/CheckContainer2", JSON.stringify({
        'item': itemid,
        'id': id
      }), function(_0xa0444a) {});
    }
  }
}



UpdateInventory = data => {

    if (data.inventory) {
        LoadInventory(data.inventory);
    } else if (data.safeinventory) {
        LoadSafeInventory(data.safeinventory, "protected");
    }
}

function FastMove(itemName) {
  itemid = itemName;
  which = LastData.hangi;

  if (DisableInventoryMove == true) {
    return;
  }

  if (typeof which == 'undefined' || which == null) {
    return;
  }

  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;
  const isSmallScreen = screenWidth <= 1600 && screenHeight <= 1400;

  if (which == 'normal') {
    if (combatmode == true) {
      return;
    }
    if (OtherWeight + normalinventoryitem[itemid].weight > OtherMaxWeight) {
      return;
    }
    safecount = $("#item-slot-" + itemid).data("count");
    if (safecount > 1) {
      x = safecount - 1;
      check = document.getElementById("normal-count-" + itemid).innerHTML = 'x' + x;
      if (typeof check === "undefined" || check === null) {
        return;
      }
      $("#item-slot-" + itemid).data("count", x);
      if ($("#safe-item-slot-" + itemid).length > 0) {
        safecount = $('#safe-item-slot-' + itemid).data("count");
        updatesafecount = safecount + 1;
        $("#safe-item-slot-" + itemid).data("count", updatesafecount);
        $("#safe-item-slot-" + itemid).data('item', itemid);
        document.getElementById("safe-count-" + itemid).innerHTML = 'x' + updatesafecount;
        $.post("https://gamemode/CheckItems", JSON.stringify({
          'item': itemid
        }), function (_0x2ed332) {});
      } else {
        const content = `
          <div class="item-slot" id="safe-item-slot-${itemid}" onclick="FastMove('${itemid}')" onmouseenter="FastSlot('${itemid}', 'safe')" data-itemdata=${JSON.stringify({itemName: itemid, itemCount: 1, currentContainer: "protected"})}>
            <span class="details-name" id="safe-count-${itemid}">x1</span>
            <div class="icon-container">
              <img class="icon" src="assets/items/${itemid}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''}">
            </div>
            <div class="details-container">
              <span class="item-name">${normalinventoryitem[itemid].label}</span>
            </div>
          </div>
        `;
        $(".inventory-wrapper.inventory.safe > .items-container").append(content);
        $("#safe-item-slot-" + itemid).data("item", itemid);
        $("#safe-item-slot-" + itemid).data("count", 1);
        $.post("https://gamemode/CheckItems", JSON.stringify({
          'item': itemid
        }), function (_0x5c8bee) {});
      }
    } else {
      if ($("#safe-item-slot-" + itemid).length > 0) {
        safecount = $('#safe-item-slot-' + itemid).data("count");
        updatesafecount = safecount + 1;
        $("#safe-item-slot-" + itemid).data("count", updatesafecount);
        $("#safe-item-slot-" + itemid).data('item', itemid);
        document.getElementById("safe-count-" + itemid).innerHTML = 'x' + updatesafecount;
      } else {
        const content = `
          <div class="item-slot" id="safe-item-slot-${itemid}" onclick="FastMove('${itemid}')" onmouseenter="FastSlot('${itemid}', 'safe')" data-itemdata=${JSON.stringify({itemName: itemid, itemCount: 1, currentContainer: "protected"})}>
            <span class="details-name" id="safe-count-${itemid}">x1</span>
            <div class="icon-container">
              <img class="icon" src="assets/items/${itemid}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''}">
            </div>
            <div class="details-container">
              <span class="item-name">${normalinventoryitem[itemid].label}</span>
            </div>
          </div>
        `;
        $(".inventory-wrapper.inventory.safe > .items-container").append(content);
        $("#safe-item-slot-" + itemid).data("item", itemid);
        $("#safe-item-slot-" + itemid).data("count", 1);
      }
      $("#item-slot-" + itemid).remove();
      $.post("https://gamemode/CheckItems", JSON.stringify({
        'item': itemid
      }), function (_0xa0444a) {});
    }
  } else {
    if (PlayerWeight + normalinventoryitem[itemid].weight > PlayerMaxWeight) {
      return;
    }
    safecount = $("#safe-item-slot-" + itemid).data("count");
    if (safecount > 1) {
      x = safecount - 1;
      check = document.getElementById("safe-count-" + itemid).innerHTML = 'x' + x;
      if (typeof check === "undefined" || check === null) {
        return;
      }
      $("#safe-item-slot-" + itemid).data("count", x);
      if ($("#item-slot-" + itemid).length > 0) {
        f = $('#item-slot-' + itemid).data("count");
        c = f + 1;
        $("#item-slot-" + itemid).data("item", itemid);
        $("#item-slot-" + itemid).data("count", c);
        document.getElementById("normal-count-" + itemid).innerHTML = 'x' + c;
        $.post("https://gamemode/CheckItemsSafe", JSON.stringify({
          'item': itemid
        }), function (_0x2b0547) {});
      } else {
        const content = `
          <div class="item-slot" id="item-slot-${itemid}" onclick="FastMove('${itemid}')" onmouseenter="FastSlot('${itemid}', 'normal')" data-itemdata=${JSON.stringify({itemName: itemid, itemCount: 1, currentContainer: "inventory"})}>
            <span class="details-name" id="normal-count-${itemid}">x1</span>
            <div class="icon-container">
              <img class="icon" src="assets/items/${itemid}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''}">
            </div>
            <div class="details-container">
              <span class="item-name">${normalinventoryitem[itemid].label}</span>
            </div>
          </div>
        `;
        $(".inventory-wrapper.inventory.self > .items-container").append(content);
        $("#item-slot-" + itemid).data("item", itemid);
        $("#item-slot-" + itemid).data("count", 1);
        $.post("https://gamemode/CheckItemsSafe", JSON.stringify({
          'item': itemid
        }), function (_0x5e2837) {});
      }
    } else {
      if ($("#item-slot-" + itemid).length > 0) {
        za = $('#item-slot-' + itemid).data("count");
        updatesafecount = za + 1;
        $("#item-slot-" + itemid).data('item', itemid);
        $("#item-slot-" + itemid).data("count", updatesafecount);
        document.getElementById("normal-count-" + itemid).innerHTML = 'x' + updatesafecount;
      } else {
        const content = `
          <div class="item-slot" id="item-slot-${itemid}" onclick="FastMove('${itemid}')" onmouseenter="FastSlot('${itemid}', 'normal')" data-itemdata=${JSON.stringify({itemName: itemid, itemCount: 1, currentContainer: "inventory"})}>
            <span class="details-name" id="normal-count-${itemid}">x1</span>
            <div class="icon-container">
              <img class="icon" src="assets/items/${itemid}.png" style="${isSmallScreen ? 'width: 157%; height: 90%;' : ''}">
            </div>
            <div class="details-container">
              <span class="item-name">${normalinventoryitem[itemid].label}</span>
            </div>
          </div>
        `;
        $(".inventory-wrapper.inventory.self > .items-container").append(content);
        $("#item-slot-" + itemid).data("item", itemid);
        $("#item-slot-" + itemid).data("count", 1);
      }
      $("#safe-item-slot-" + itemid).remove();
      $.post("https://gamemode/CheckItemsSafe", JSON.stringify({
        'item': itemid
      }), function (_0xa0444a) {});
    }
  }
}



$(document).on("keydown", function (e) {
    switch (e.which) {
        // case 16:
        //     ShiftPressed = true
        //     break;
        // case 17:
        //     ControlPressed = true
        //     break;
    }
})

const HotBarKeys = {
    49: 1,
    50: 2,
    51: 3,
    52: 4,
    53: 5,
    54: 6,
    55: 7
}

Config = {
    CloseKeys: ["Escape"]
}

InShop = false

MouseData = null 
$(document).on("keyup", function (e) {
  // switch (e.which) {
  //     case 16:
  //         ShiftPressed = false
  //         break;
  //     case 17:
  //         ControlPressed = false
  //         break;
  // }
  $.each(HotBarKeys, function (k, v) {
      if (e.which == k && MouseData) {
        console.log("sending post")
          $.post("https://gamemode/SetHotbar", JSON.stringify({ id: v, itemName: MouseData.itemName }));
      }
  });
  $.each(Config.CloseKeys, function (k, v) {
      if (e.key == v) {
          $.post("https://gamemode/Close");
          if (InShop) {
              InShop = false;
              LoadShop({bool: false})
          }
      }
  });
})

$(document).on("mouseenter", ".item-slot", function () {
  const itemData = $(this).data("itemdata")
  MouseData = itemData
})

$(document).on("mouseleave", ".item-slot", function () {
  MouseData = null
})



function SetSettingsValue(index) {
  if (index == "opacity") {

    const inputElement = document.querySelector('.option-input-number');
    if (inputElement) {
      const inputValue = inputElement.value;
      // console.log(inputValue);
      $(".extinction-content").css("background-color", "rgba(19, 21, 23, " + inputValue + ")");
    } else {
      // console.error('Element with ID "option-input-number" not found.');
    }

  }
}

// document.addEventListener('DOMContentLoaded', function () {
//   LoadMyInventorySide([
//     { name: "weapon_heavysniper", label: "AWP", count: 4 },
//   ], "inventory", "inventory")
//   LoadContainerBag([
//     { name: "weapon_heavysniper_mk2", label: "AWP Mk II", count: 1 },
//   ], "container", "container-5505005")
//   ChangePages('container');
//     $(".extinction-body").show();
//     const element = document.querySelector('.extinction-body');
//     if (element) {
//         element.style.display = 'flex';
//     }
// });
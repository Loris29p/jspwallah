const timers = {};
const intervals = {};

const effectTimers = {
  antizin: { duration: 360 },
  spawncar: { duration: 3 },
  babygod: { duration: 2 },
  safezone: { duration: 5 },
  flesh: { duration: 180 }
};

window.addEventListener('message', function(e) {
    const data = e.data;
    if (data.type === 'updateStatus') {
        SetHealth(data.health);
        SetArmor(data.armor);
    } else if (data.type === 'showHud') {
        ShowHud(data.show);
    } else if (data.type === 'showHudExtraContainer') {
        ShowHudExtraContainer(data.extraType, data.show, data.value);
    } else if (data.type == "startEffect") {
      startEffect(data.effect);
      console.log(data.effect, "start effect ??");
    }
});

function ShowHud(bool) {
    if (bool) {
        $('.hud-status-container').css('display', 'block');
    } else {
        $('.hud-status-container').css('display', 'none');
    }
}


function SetHealth(health) {
    const fillElement = $('.status-row.health .bar-container .bar-full .fill');
    
    if (health > 0) {
        fillElement.css('width', health + '%');
    } else {
        fillElement.css('width', health + '%');
    }

    if (health < 25) {
        fillElement.addClass('warning');
    } else {
        fillElement.removeClass('warning');
    }
}

function SetArmor(armor) {
    if (armor === 0) {
        $('.status-row.armor').remove();
        return;
    }
    if ($('.status-container .status-row.armor').length === 0) {
        const armorRow = `
            <div class="status-row armor">
                      <div class="status-icon">
                        <div class="react-svg" style="margin-bottom: 0.25vh;">
                          <div>
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 100 125" width="20" height="20" enable-background="new 0 0 100 100" xml:space="preserve" class="injected-svg" data-src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMTAwIDEyNSIgZW5hYmxlLWJhY2tncm91bmQ9Im5ldyAwIDAgMTAwIDEwMCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHBhdGggZD0iTTc5LjMzOSw1Ny44OTJWNTIuMzljMC0xLjIyLTAuOTEzLTIuMjI0LTIuMDk0LTIuMzY5YzAtMi4xODksMC0zLjY2MSwwLTMuOTNjMC0xLjQ2OCwwLjA4OS0xLjkwNC0xLjIzMS0zLjAzOSAgYy0xLjI1OC0xLjA4Mi00Ljk5My0yLjk1LTQuOTkzLTExLjgxOWMwLTQuMzMsMS41MzctNy42MTIsMi4wOTUtOC45MzlzMi4wOTUtNC4zMjksMC41NTktNC44MTggIGMtMS4xNzQtMC4zNzQtOC45MjItMi4yOTktMTIuNTA1LTMuMTg0Yy0xLjEwNC0wLjI3My0yLjI1MiwwLjM3Ny0yLjUwOSwwLjc2OWMtMS44NjksMi44NS01LjAwNCw0LjkwOC04LjY2MSw1LjEwNCAgYy0zLjY1Ny0wLjE5Ni02Ljc5Mi0yLjI1NS04LjY2MS01LjEwNGMtMC4yNTctMC4zOTItMS40MDYtMS4wNDItMi41MDktMC43NjljLTMuNTgzLDAuODg1LTExLjMzMSwyLjgxLTEyLjUwNSwzLjE4NCAgYy0xLjUzNywwLjQ4OSwwLDMuNDkxLDAuNTU5LDQuODE4czIuMDk1LDQuNjA5LDIuMDk1LDguOTM5YzAsOC44NjktMy43MzUsMTAuNzM3LTQuOTkzLDExLjgxOWMtMS4zMiwxLjEzNS0xLjIzMSwxLjU3MS0xLjIzMSwzLjAzOSAgYzAsMC4yNjksMCwxLjc0LDAsMy45M2MtMS4xODEsMC4xNDYtMi4wOTQsMS4xNDktMi4wOTQsMi4zNjl2NS41MDJjMCwxLjIxOSwwLjkxMywyLjIyMywyLjA5NCwyLjM2OGMwLDEuMzkyLDAsMi44MSwwLDQuMjE3ICBjLTEuMTgxLDAuMTQ2LTIuMDk0LDEuMTQ5LTIuMDk0LDIuMzY5djUuNTAyYzAsMS4yMiwwLjkxMywyLjIyNCwyLjA5NCwyLjM2OWMwLDMuMjE1LDAsNS40NTUsMCw1LjczMyAgYzAsMS4yNzMsMC4zNTEsMi42MjQsMi42MjcsMy4yMjlDMzAuOSw4NS4xNDYsMzkuNzY5LDg1Ljc3NCw1MCw4NS43NzRjOC45NzUsMCwxOS40NS0wLjgzOSwyNC42MTgtMi4wOTUgIGMyLjI4OC0wLjU1NywyLjYyNy0xLjk1NiwyLjYyNy0zLjIyOWMwLTAuMjc4LDAtMi41MTksMC01LjczM2MxLjE4MS0wLjE0NiwyLjA5NC0xLjE0OSwyLjA5NC0yLjM2OXYtNS41MDIgIGMwLTEuMjItMC45MTMtMi4yMjQtMi4wOTQtMi4zNjljMC0xLjQwNywwLTIuODI1LDAtNC4yMTdDNzguNDI2LDYwLjExNCw3OS4zMzksNTkuMTEsNzkuMzM5LDU3Ljg5MnoiLz48dGV4dCB4PSIwIiB5PSIxMTUiIGZpbGw9IiMwMDAwMDAiIGZvbnQtc2l6ZT0iNXB4IiBmb250LXdlaWdodD0iYm9sZCIgZm9udC1mYW1pbHk9IidIZWx2ZXRpY2EgTmV1ZScsIEhlbHZldGljYSwgQXJpYWwtVW5pY29kZSwgQXJpYWwsIFNhbnMtc2VyaWYiPkNyZWF0ZWQgYnkgbW9jaGFuZHlzaXNtYW50bzwvdGV4dD48dGV4dCB4PSIwIiB5PSIxMjAiIGZpbGw9IiMwMDAwMDAiIGZvbnQtc2l6ZT0iNXB4IiBmb250LXdlaWdodD0iYm9sZCIgZm9udC1mYW1pbHk9IidIZWx2ZXRpY2EgTmV1ZScsIEhlbHZldGljYSwgQXJpYWwtVW5pY29kZSwgQXJpYWwsIFNhbnMtc2VyaWYiPmZyb20gdGhlIE5vdW4gUHJvamVjdDwvdGV4dD48L3N2Zz4=">
                              <path d="M79.339,57.892V52.39c0-1.22-0.913-2.224-2.094-2.369c0-2.189,0-3.661,0-3.93c0-1.468,0.089-1.904-1.231-3.039  c-1.258-1.082-4.993-2.95-4.993-11.819c0-4.33,1.537-7.612,2.095-8.939s2.095-4.329,0.559-4.818  c-1.174-0.374-8.922-2.299-12.505-3.184c-1.104-0.273-2.252,0.377-2.509,0.769c-1.869,2.85-5.004,4.908-8.661,5.104  c-3.657-0.196-6.792-2.255-8.661-5.104c-0.257-0.392-1.406-1.042-2.509-0.769c-3.583,0.885-11.331,2.81-12.505,3.184  c-1.537,0.489,0,3.491,0.559,4.818s2.095,4.609,2.095,8.939c0,8.869-3.735,10.737-4.993,11.819c-1.32,1.135-1.231,1.571-1.231,3.039  c0,0.269,0,1.74,0,3.93c-1.181,0.146-2.094,1.149-2.094,2.369v5.502c0,1.219,0.913,2.223,2.094,2.368c0,1.392,0,2.81,0,4.217  c-1.181,0.146-2.094,1.149-2.094,2.369v5.502c0,1.22,0.913,2.224,2.094,2.369c0,3.215,0,5.455,0,5.733  c0,1.273,0.351,2.624,2.627,3.229C30.9,85.146,39.769,85.774,50,85.774c8.975,0,19.45-0.839,24.618-2.095  c2.288-0.557,2.627-1.956,2.627-3.229c0-0.278,0-2.519,0-5.733c1.181-0.146,2.094-1.149,2.094-2.369v-5.502  c0-1.22-0.913-2.224-2.094-2.369c0-1.407,0-2.825,0-4.217C78.426,60.114,79.339,59.11,79.339,57.892z"></path>
                              <text x="0" y="115" fill="#000000" font-size="5px" font-weight="bold" font-family="'Helvetica Neue', Helvetica, Arial-Unicode, Arial, Sans-serif">Created by mochandysismanto</text>
                              <text x="0" y="120" fill="#000000" font-size="5px" font-weight="bold" font-family="'Helvetica Neue', Helvetica, Arial-Unicode, Arial, Sans-serif">from the Noun Project</text>
                            </svg>
                          </div>
                        </div>
                      </div>
                      <div class="bar-container">
                        <div class="bar-full">
                          <div class="fill-full">
                            <div class="bar-tick border-1"></div>
                            <div class="bar-tick border-2"></div>
                            <div class="bar-tick border-3"></div>
                            <div class="fill" style="width: 100%;"></div>
                          </div>
                        </div>
                      </div>
                    </div>
        `;
        $('.status-container').append(armorRow);
    }
    $('.status-row.armor .bar-container .bar-full .fill-full .fill').css('width', armor + '%');
}



function ShowHudExtraContainer(type, bool, value) {
    if (bool) {
        $('.extra-container').css('display', 'flex');
        if (type == "kills") {
            $('.extra-container .kills-column').css('display', 'block');
            AddColumnExtra(type, value);
        }
    } else {
        $('.extra-container').css('display', 'none');
        if (type == "kills") {
            $('.extra-container .kills-column').css('display', 'none');
            AddColumnExtra(type, value);
        }
    }
}


function AddColumnExtra(type, value) {
    if (type === "kills") {
        const killsColumn = $('.extra-container .kills-column .kill.white');
        if (killsColumn.length > 0) {
            killsColumn.empty();
            const kills = `
            <div class="kill-icon">
            <div>
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 1133.9 1417.375" enable-background="new 0 0 1133.9 1133.9" xml:space="preserve" class="injected-svg" data-src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMTEzMy45IDE0MTcuMzc1IiBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCAxMTMzLjkgMTEzMy45IiB4bWw6c3BhY2U9InByZXNlcnZlIj48cGF0aCBkPSJNOTI3LjEsNjg1LjNjOC4xLTI3LjQsMTUtNTUuNSwyMi4zLTgzLjdjMTYuOS02NS42LDIzLjMtMTMzLDExLjgtMjAwYy0xNy4xLTk5LjktNjAuMy0xNzguMi0xMzIuMi0yMzcuNCAgYy03MC4yLTU4LjMtMTU3LjEtODYuOS0yNTguNy04Ni41Yy0xMi4yLDAtMjQuNi0wLjktMzYuNywwYy0xNS40LDEuMi0zMC43LDIuOS00NS43LDUuOGMtMTIxLjIsMjIuNy0yMDkuNiw3Ny4xLTI2Ny4yLDE3Ni40ICBjLTUxLjIsODcuNS02MiwxODkuNi0zNS40LDI5Ni42YzEyLjMsNDkuMywyNi4xLDk3LjMsNDEuOCwxNDRjMS43LDUuMSw0LjIsMTAsMC43LDE2LjFjLTIzLjMsNDAuMi0xOC43LDc4LjgsMS44LDExMy43ICBjMTYuNiwyOC4zLDQzLjUsNDUuMiw3MC43LDYxLjdjMTMuNiw4LjMsMjguMywxMi44LDQ1LjcsOS4xYzQuNC0xLDktMC42LDEzLjYtMC43YzM5LjMtMC4yLDYwLjYsODMuMyw2MS4zLDEyMS44ICBjMC4xLDkuMiwxOC4xLDIwLjUsMjcuMywxNy4zYzMuNy0xLjMsMy41LTQuMiwzLjYtNi45YzAuMy02LjEsMC40LTU1LjUsMC43LTYxLjZjMC4xLTIuNiwxLjEtNC45LDQuMi01LjJjMy44LTAuNCw0LjksMiw0LjgsNSAgYy0wLjEsNy4xLTAuMiw1Ny41LTAuNCw2NC42Yy0wLjIsNC41LDAuOCw4LDYsOWMxMi44LDIuNSwyNS44LDQuNiwzOS4xLDUuNWM1LjcsMC40LDcuOS0xLjgsNy45LTdjMC05LjUsMC4yLTYyLjIsMC40LTcxLjcgIGMwLjEtMy0wLjMtNi43LDQuMi03LjFjNS4zLTAuNSw1LDMuNyw1LDdjMCw5LjUsMC4xLDYyLjItMC4zLDcxLjdjLTAuMyw2LjQsMi45LDkuNSw5LjMsOS42YzEyLjIsMC4zLDI0LjUsMC4zLDM2LjcsMC42ICBjNS44LDAuMSw3LjItMy4yLDcuMi03LjhjLTAuMS05LjgtMC4xLTYyLjgsMC4xLTcyLjdjMC4xLTMuNC0xLjQtOC41LDQuMy04LjdjNS44LTAuMiw0LjksNC45LDQuOSw4LjRjMC4yLDkuMSwwLjQsNjEuNSwwLjEsNzAuNiAgYy0wLjMsOCwzLjQsMTEsMTEuNywxMC40YzExLjEtMC44LDIyLjItMS4yLDMzLjMtMS42YzUuOC0wLjIsOC4xLTMsNy45LTguNGMtMC4zLTkuNS0wLjQtNjIuMi0wLjQtNzEuN2MwLTMtMC42LTYuOCwzLjktNyAgYzUuMy0wLjMsNS4zLDMuOCw1LjQsNy4yYzAuMyw4LjUsMC41LDYwLjIsMC41LDY4LjZjMCw2LjUsMi40LDkuNiw5LjgsOC4yYzEwLjUtMS45LDIwLjktMy43LDMxLjUtNC45YzguNS0wLjksMTEuMy01LjMsMTAuNS0xMyAgYy0wLjMtMi43LTAuNS01NS4yLTAuMi01Ny44YzAuNS00LjMtMi44LTUuNywzLjQtNS40YzcuNCwwLjMsNC4yLDEuNyw0LjYsNi4xYzQuNCw0MS42LTkuOCw4Ni4xLDE3LjcsNjAuN2MzLjMtMy4xLDUuMi00LjcsNC45LTguOCAgYy0wLjMtNS44LTAuNy0xMS42LTAuNi0xNy40YzAuNS0yOCwxMi43LTEwNy41LDM5LjgtMTE0LjRjMTUuNy0zLjksMzItNC4xLDQ4LjQtMC40YzkuMSwyLDE2LjksMS4yLDI1LTEuOSAgYzI4LjctMTEuMyw1Mi4yLTI5LjQsNzMuOC01MC4zYzE1LTE0LjUsMjUuNS0zMi41LDI5LjgtNTRjNi4zLTMxLjEsNS42LTYyLjQtMTguNS04OC45QzkyNC41LDY5My42LDkyNS44LDY4OS43LDkyNy4xLDY4NS4zeiAgIE00ODUuOSw2ODMuM2MtMjQuMiwxNi00NS45LDM0LjctNzUuMyw0Ni4xYy01My43LDIwLjctMTA0LjYtNi41LTExOC40LTQ1Yy00LjYtMTItNi44LTI0LjMtNy45LTM2LjZjLTEuMi0xMy4zLDEtMjYuMywzLjItMzkuMyAgYzQuNS0yNy42LDEzLjYtNTMuMywzMS40LTc2YzUuNS03LDExLjktMTEuNywyMC40LTE0LjRjMTMuMi00LjMsMjYuNC02LjgsNDAuMS03LjVjMzYuMS0yLDcxLTIsMTA3LjEsMy45ICBjMzkuOSw2LjEsNTEuOSwxNCw1NC44LDYxLjVDNTQzLjcsNjE2LjgsNTI4LjEsNjU1LjEsNDg1LjksNjgzLjN6IE01NjUuNCw3OTEuNWMtMi43LDYtNy4yLDkuNS0xNC4yLDkuM2MtMy41LTAuMS03LDAuMi0xMC4yLDAuMyAgYy00LjctMS05LjMtMS41LTEzLjUtMi45Yy01LjItMS43LTguMS01LjktOS40LTExLjJjLTEuNy02LjgtMS4zLTEzLjcsMC44LTIwLjJjNS42LTE3LjcsMTQuNi0zNCwyMC41LTUxLjYgIGMyLjMtNy4xLDQuNi0xMi41LDkuMy04LjZjNS41LDAuMiw2LjYsNS42LDcuNyw5LjljNSwxOS4xLDkuMSwzOC40LDExLjcsNTcuOUM1NjkuMSw3ODAuMiw1NjcuOSw3ODYuMSw1NjUuNCw3OTEuNXogTTYzMCw3ODcuNCAgYy0xLjYsNi4zLTUuNCwxMC42LTEyLjQsMTEuNmMtMy41LDAuNS02LjksMS40LTEwLDIuMWMtNC44LTAuMS05LjQsMC4yLTEzLjgtMC41Yy01LjQtMC44LTktNC41LTExLjItOS40ICBjLTIuOC02LjQtMy42LTEzLjItMi43LTIwLjFjMi40LTE4LjQsNi4xLTM2LjYsMTEuMi01NC40YzEuMi00LjMsMi42LTkuNSw3LjctMTAuMWM1LjQtMC43LDcuNSw0LjQsOS4zLDguNCAgYzguMiwxNy45LDE1LjYsMzYuMiwyMS42LDU1QzYzMS42LDc3NS42LDYzMS41LDc4MS42LDYzMCw3ODcuNHogTTg2Mi43LDY3NS40Yy0xMS40LDM3LjYtNTguMSw2Ny44LTExNS43LDQ3LjggIGMtNDAuMS0xNC03NC42LTM1LjUtMTAyLjgtNjAuNWMtMzYuMS0zMi4yLTQzLjUtNzIuMy0zNC44LTExMy4xYzMuMy0xNS41LDEyLjctMjUuOCwyOS41LTMwLjVjMzguNC0xMC44LDc1LjEtMTQsMTEzLjYtMTQuNSAgYzE4LjItMC4yLDM1LjktMC4xLDUzLjcsNS43YzcuNCwyLjQsMTMuNCw2LjEsMTguNiwxMmMyMy4zLDI2LDM0LDU2LjksNDAuNSw4OS42Qzg3MC4yLDYzMi44LDg2OS41LDY1NC4zLDg2Mi43LDY3NS40eiIvPjx0ZXh0IHg9IjAiIHk9IjExNDguOSIgZmlsbD0iIzAwMDAwMCIgZm9udC1zaXplPSI1cHgiIGZvbnQtd2VpZ2h0PSJib2xkIiBmb250LWZhbWlseT0iJ0hlbHZldGljYSBOZXVlJywgSGVsdmV0aWNhLCBBcmlhbC1Vbmljb2RlLCBBcmlhbCwgU2Fucy1zZXJpZiI+Q3JlYXRlZCBieSBBbHZhcm8gQ2FicmVyYTwvdGV4dD48dGV4dCB4PSIwIiB5PSIxMTUzLjkiIGZpbGw9IiMwMDAwMDAiIGZvbnQtc2l6ZT0iNXB4IiBmb250LXdlaWdodD0iYm9sZCIgZm9udC1mYW1pbHk9IidIZWx2ZXRpY2EgTmV1ZScsIEhlbHZldGljYSwgQXJpYWwtVW5pY29kZSwgQXJpYWwsIFNhbnMtc2VyaWYiPmZyb20gdGhlIE5vdW4gUHJvamVjdDwvdGV4dD48L3N2Zz4=">
                <path d="M927.1,685.3c8.1-27.4,15-55.5,22.3-83.7c16.9-65.6,23.3-133,11.8-200c-17.1-99.9-60.3-178.2-132.2-237.4  c-70.2-58.3-157.1-86.9-258.7-86.5c-12.2,0-24.6-0.9-36.7,0c-15.4,1.2-30.7,2.9-45.7,5.8c-121.2,22.7-209.6,77.1-267.2,176.4  c-51.2,87.5-62,189.6-35.4,296.6c12.3,49.3,26.1,97.3,41.8,144c1.7,5.1,4.2,10,0.7,16.1c-23.3,40.2-18.7,78.8,1.8,113.7  c16.6,28.3,43.5,45.2,70.7,61.7c13.6,8.3,28.3,12.8,45.7,9.1c4.4-1,9-0.6,13.6-0.7c39.3-0.2,60.6,83.3,61.3,121.8  c0.1,9.2,18.1,20.5,27.3,17.3c3.7-1.3,3.5-4.2,3.6-6.9c0.3-6.1,0.4-55.5,0.7-61.6c0.1-2.6,1.1-4.9,4.2-5.2c3.8-0.4,4.9,2,4.8,5  c-0.1,7.1-0.2,57.5-0.4,64.6c-0.2,4.5,0.8,8,6,9c12.8,2.5,25.8,4.6,39.1,5.5c5.7,0.4,7.9-1.8,7.9-7c0-9.5,0.2-62.2,0.4-71.7  c0.1-3-0.3-6.7,4.2-7.1c5.3-0.5,5,3.7,5,7c0,9.5,0.1,62.2-0.3,71.7c-0.3,6.4,2.9,9.5,9.3,9.6c12.2,0.3,24.5,0.3,36.7,0.6  c5.8,0.1,7.2-3.2,7.2-7.8c-0.1-9.8-0.1-62.8,0.1-72.7c0.1-3.4-1.4-8.5,4.3-8.7c5.8-0.2,4.9,4.9,4.9,8.4c0.2,9.1,0.4,61.5,0.1,70.6  c-0.3,8,3.4,11,11.7,10.4c11.1-0.8,22.2-1.2,33.3-1.6c5.8-0.2,8.1-3,7.9-8.4c-0.3-9.5-0.4-62.2-0.4-71.7c0-3-0.6-6.8,3.9-7  c5.3-0.3,5.3,3.8,5.4,7.2c0.3,8.5,0.5,60.2,0.5,68.6c0,6.5,2.4,9.6,9.8,8.2c10.5-1.9,20.9-3.7,31.5-4.9c8.5-0.9,11.3-5.3,10.5-13  c-0.3-2.7-0.5-55.2-0.2-57.8c0.5-4.3-2.8-5.7,3.4-5.4c7.4,0.3,4.2,1.7,4.6,6.1c4.4,41.6-9.8,86.1,17.7,60.7c3.3-3.1,5.2-4.7,4.9-8.8  c-0.3-5.8-0.7-11.6-0.6-17.4c0.5-28,12.7-107.5,39.8-114.4c15.7-3.9,32-4.1,48.4-0.4c9.1,2,16.9,1.2,25-1.9  c28.7-11.3,52.2-29.4,73.8-50.3c15-14.5,25.5-32.5,29.8-54c6.3-31.1,5.6-62.4-18.5-88.9C924.5,693.6,925.8,689.7,927.1,685.3z   M485.9,683.3c-24.2,16-45.9,34.7-75.3,46.1c-53.7,20.7-104.6-6.5-118.4-45c-4.6-12-6.8-24.3-7.9-36.6c-1.2-13.3,1-26.3,3.2-39.3  c4.5-27.6,13.6-53.3,31.4-76c5.5-7,11.9-11.7,20.4-14.4c13.2-4.3,26.4-6.8,40.1-7.5c36.1-2,71-2,107.1,3.9  c39.9,6.1,51.9,14,54.8,61.5C543.7,616.8,528.1,655.1,485.9,683.3z M565.4,791.5c-2.7,6-7.2,9.5-14.2,9.3c-3.5-0.1-7,0.2-10.2,0.3  c-4.7-1-9.3-1.5-13.5-2.9c-5.2-1.7-8.1-5.9-9.4-11.2c-1.7-6.8-1.3-13.7,0.8-20.2c5.6-17.7,14.6-34,20.5-51.6  c2.3-7.1,4.6-12.5,9.3-8.6c5.5,0.2,6.6,5.6,7.7,9.9c5,19.1,9.1,38.4,11.7,57.9C569.1,780.2,567.9,786.1,565.4,791.5z M630,787.4  c-1.6,6.3-5.4,10.6-12.4,11.6c-3.5,0.5-6.9,1.4-10,2.1c-4.8-0.1-9.4,0.2-13.8-0.5c-5.4-0.8-9-4.5-11.2-9.4  c-2.8-6.4-3.6-13.2-2.7-20.1c2.4-18.4,6.1-36.6,11.2-54.4c1.2-4.3,2.6-9.5,7.7-10.1c5.4-0.7,7.5,4.4,9.3,8.4  c8.2,17.9,15.6,36.2,21.6,55C631.6,775.6,631.5,781.6,630,787.4z M862.7,675.4c-11.4,37.6-58.1,67.8-115.7,47.8  c-40.1-14-74.6-35.5-102.8-60.5c-36.1-32.2-43.5-72.3-34.8-113.1c3.3-15.5,12.7-25.8,29.5-30.5c38.4-10.8,75.1-14,113.6-14.5  c18.2-0.2,35.9-0.1,53.7,5.7c7.4,2.4,13.4,6.1,18.6,12c23.3,26,34,56.9,40.5,89.6C870.2,632.8,869.5,654.3,862.7,675.4z"></path>
                <text x="0" y="1148.9" fill="#000000" font-size="5px" font-weight="bold" font-family="'Helvetica Neue', Helvetica, Arial-Unicode, Arial, Sans-serif">Created by Alvaro Cabrera</text>
                <text x="0" y="1153.9" fill="#000000" font-size="5px" font-weight="bold" font-family="'Helvetica Neue', Helvetica, Arial-Unicode, Arial, Sans-serif">from the Noun Project</text>
                </svg>
            </div>
            </div>
            <span>${value}</span>
            `
            $('.extra-container .kills-column .kill.white').append(kills);
        }
    }
}

const activeTimers = {};

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
}

function initializeEffect(effectName, duration) {
    const effect = document.querySelector(`.${effectName}`);
    if (!effect) {
        console.error(`Effet introuvable: ${effectName}`);
        return;
    }

    const timeDisplay = effect.querySelector('.time');
    const progressPath = effect.querySelector('.CircularProgressbar-path');

    resetEffect(effect);
    timeDisplay.textContent = formatTime(duration);
    progressPath.style.strokeDashoffset = '289.027';
    effect.style.display = '';
    $(effect).hide().fadeIn(100, () => startCountdown(effectName, duration, timeDisplay, progressPath));
}

function startCountdown(effectName, duration, timeDisplay, progressPath) {
    let remainingTime = duration;
    const timerId = setInterval(() => {
        remainingTime--;
        timeDisplay.textContent = formatTime(remainingTime);
        
        const progress = (remainingTime / duration) * 289.027;
        progressPath.style.strokeDashoffset = progress;

        if (remainingTime <= 0) {
            clearInterval(timerId);
            completeEffect(effectName);
        }
    }, 1000);

    activeTimers[effectName] = timerId;
    $('.extra-container').css('display', 'flex');
}

function completeEffect(effectName) {
    $.post(`https://gamemode/hudEffects`, JSON.stringify({ effect: effectName, state: false }));
    hideEffect(effectName);
}

function hideEffect(effectName) {
    const effect = document.querySelector(`.${effectName}`);
    if (effect) {
        effect.style.display = 'none';
    }
}

function resetEffect(effect) {
    const timeDisplay = effect.querySelector('.time');
    const progressPath = effect.querySelector('.CircularProgressbar-path');
    
    timeDisplay.textContent = '';
    progressPath.style.strokeDashoffset = '289.027';
}

function startEffect(effectName) {
    let duration = 5;

    switch (effectName) {
        case "antizin": duration = 360; break;
        case "spawncar": duration = 3; break;
        case "babygod": duration = 2; break;
        case "safezone": duration = 5; break;
        case "flesh": duration = 180; break;
    }

    if (activeTimers[effectName]) {
        clearInterval(activeTimers[effectName]);
        hideEffect(effectName);
    }

    initializeEffect(effectName, duration);
}

document.addEventListener('DOMContentLoaded', () => {
    console.log("Document chargé");
    const effectNames = ['antizin', 'spawncar', 'babygod', 'safezone', 'flesh'];
    effectNames.forEach(name => hideEffect(name));
});

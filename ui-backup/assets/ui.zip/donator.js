window.addEventListener('message', function(event) {
    const data = event.data;
    if (data.type == "donator") {
        // if (data.bool) {
        //     $(".extinction-donator-shop").css("display", "flex");
        // } else {
        //     $(".extinction-donator-shop").css("display", "none");
        // }
    }
});

function ChangeDonatorPages(str) {
    if (str == "rank") {
        togglePrimaryClass("rank-button", "daily-button");
        togglePrimaryClass("rank-button", "weapon-button");
        togglePrimaryClass("rank-button", "myskins-button");
        $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content").empty();
        const content = `
        <div class="category-items full">
                            <div class="premium-shop-rank-table">
                              <table class="shop-items-table">
                                <thead>
                                  <tr>
                                    <th class="title"></th>
                                    <th class="value">
                                      <div class="image">
                                      </div>
                                    </th>
                                    <th class="value">
                                      <div class="image">
                                      </div>
                                    </th>
                                  </tr>
                                  <tr>
                                    <th class="title"></th>
                                    <th class="value">
                                      <div class="name">Gold</div>
                                    </th>
                                    <th class="value">
                                      <div class="name">Diamond</div>
                                    </th>
                                  </tr>
                                  <tr>
                                    <th class="title"></th>
                                    <th class="value">
                                      <div class="description">🟨 Gold rank in-game &amp; discord</div>
                                    </th>
                                    <th class="value">
                                      <div class="description">💎 Diamond rank in-game &amp; discord</div>
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td class="title">Discord role &amp; chat color</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">Unlock all player models available in the character creation</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20"  aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">Speed boost in safe-zones &amp; lobby</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">Custom message after killing a player</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20"  aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">FX Effect (/effect) on the player you killed</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-xmark" class="svg-inline--fa fa-circle-xmark " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM180.7 180.7c-6.2 6.2-6.2 16.4 0 22.6L233.4 256l-52.7 52.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L256 278.6l52.7 52.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L278.6 256l52.7-52.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L256 233.4l-52.7-52.7c-6.2-6.2-16.4-6.2-22.6 0z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">Launch fireworks with /fw</td>
                                    <td class="value">
                                      <svg width="20" height="20"  aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-xmark" class="svg-inline--fa fa-circle-xmark " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM180.7 180.7c-6.2 6.2-6.2 16.4 0 22.6L233.4 256l-52.7 52.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L256 278.6l52.7 52.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L278.6 256l52.7-52.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L256 233.4l-52.7-52.7c-6.2-6.2-16.4-6.2-22.6 0z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">Unlimited saved outfits slots</td>
                                    <td class="value">
                                      <span>6</span>
                                    </td>
                                    <td class="value">
                                      <span>∞</span>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">Unlimited reset skin (/selfresethead)</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">Unlimited rename /nickname</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-xmark" class="svg-inline--fa fa-circle-xmark check-gray" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM180.7 180.7c-6.2 6.2-6.2 16.4 0 22.6L233.4 256l-52.7 52.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L256 278.6l52.7 52.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L278.6 256l52.7-52.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L256 233.4l-52.7-52.7c-6.2-6.2-16.4-6.2-22.6 0z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">(Guild PvP) Choose the plate of your vehicle</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-xmark" class="svg-inline--fa fa-circle-xmark " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM180.7 180.7c-6.2 6.2-6.2 16.4 0 22.6L233.4 256l-52.7 52.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L256 278.6l52.7 52.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L278.6 256l52.7-52.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L256 233.4l-52.7-52.7c-6.2-6.2-16.4-6.2-22.6 0z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">(Guild PvP) Control the in-game screen/tv to play videos with /screen</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-xmark" class="svg-inline--fa fa-circle-xmark " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM180.7 180.7c-6.2 6.2-6.2 16.4 0 22.6L233.4 256l-52.7 52.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L256 278.6l52.7 52.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L278.6 256l52.7-52.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L256 233.4l-52.7-52.7c-6.2-6.2-16.4-6.2-22.6 0z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-xmark" class="svg-inline--fa fa-circle-xmark " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM180.7 180.7c-6.2 6.2-6.2 16.4 0 22.6L233.4 256l-52.7 52.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L256 278.6l52.7 52.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L278.6 256l52.7-52.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L256 233.4l-52.7-52.7c-6.2-6.2-16.4-6.2-22.6 0z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">(Guild PvP) Special daily kit</td>
                                    <td class="value">
                                      <span>Gold</span>
                                    </td>
                                    <td class="value">
                                      <span>Diamond</span>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">(Guild PvP) XP boost</td>
                                    <td class="value">
                                      <span>3%</span>
                                    </td>
                                    <td class="value">
                                      <span>6%</span>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">(Guild PvP) Unlimited /reset_stats</td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fal" data-icon="circle-xmark" class="svg-inline--fa fa-circle-xmark " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 32a224 224 0 1 1 0 448 224 224 0 1 1 0-448zm0 480A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM180.7 180.7c-6.2 6.2-6.2 16.4 0 22.6L233.4 256l-52.7 52.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L256 278.6l52.7 52.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L278.6 256l52.7-52.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L256 233.4l-52.7-52.7c-6.2-6.2-16.4-6.2-22.6 0z"></path>
                                      </svg>
                                    </td>
                                    <td class="value">
                                      <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-check" class="svg-inline--fa fa-circle-check check-green" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                        <path fill="currentColor" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"></path>
                                      </svg>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title">price</td>
                                    <td class="value">
                                      <div class="price">800 Coins</div>
                                    </td>
                                    <td class="value">
                                      <div class="price">1,600 Coins</div>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="title"></td>
                                    <th class="value">
                                      <div class="item-time-selector">
                                        <div class="game-button primary">Mensuel</div>
                                        <div class="game-button secondary">Permanent</div>
                                      </div>
                                      <div class="shop-buy-button gift">
                                        <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="gift" class="svg-inline--fa fa-gift " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                          <path fill="currentColor" d="M190.5 68.8L225.3 128H224 152c-22.1 0-40-17.9-40-40s17.9-40 40-40h2.2c14.9 0 28.8 7.9 36.3 20.8zM64 88c0 14.4 3.5 28 9.6 40H32c-17.7 0-32 14.3-32 32v64c0 17.7 14.3 32 32 32H480c17.7 0 32-14.3 32-32V160c0-17.7-14.3-32-32-32H438.4c6.1-12 9.6-25.6 9.6-40c0-48.6-39.4-88-88-88h-2.2c-31.9 0-61.5 16.9-77.7 44.4L256 85.5l-24.1-41C215.7 16.9 186.1 0 154.2 0H152C103.4 0 64 39.4 64 88zm336 0c0 22.1-17.9 40-40 40H288h-1.3l34.8-59.2C329.1 55.9 342.9 48 357.8 48H360c22.1 0 40 17.9 40 40zM32 288V464c0 26.5 21.5 48 48 48H224V288H32zM288 512H432c26.5 0 48-21.5 48-48V288H288V512z"></path>
                                        </svg>Faire un cadeau
                                      </div>
                                      <div class="shop-buy-button">
                                        <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="basket-shopping" class="svg-inline--fa fa-basket-shopping " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
                                          <path fill="currentColor" d="M253.3 35.1c6.1-11.8 1.5-26.3-10.2-32.4s-26.3-1.5-32.4 10.2L117.6 192H32c-17.7 0-32 14.3-32 32s14.3 32 32 32L83.9 463.5C91 492 116.6 512 146 512H430c29.4 0 55-20 62.1-48.5L544 256c17.7 0 32-14.3 32-32s-14.3-32-32-32H458.4L365.3 12.9C359.2 1.2 344.7-3.4 332.9 2.7s-16.3 20.6-10.2 32.4L404.3 192H171.7L253.3 35.1zM192 304v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16s16 7.2 16 16zm96-16c8.8 0 16 7.2 16 16v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16zm128 16v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16s16 7.2 16 16z"></path>
                                        </svg>
                                        <span>buy</span>
                                      </div>
                                    </th>
                                    <th class="value">
                                      <div class="item-time-selector">
                                        <div class="game-button primary">Mensuel</div>
                                        <div class="game-button secondary">Permanent</div>
                                      </div>
                                      <div class="shop-buy-button gift">
                                        <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="gift" class="svg-inline--fa fa-gift " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                          <path fill="currentColor" d="M190.5 68.8L225.3 128H224 152c-22.1 0-40-17.9-40-40s17.9-40 40-40h2.2c14.9 0 28.8 7.9 36.3 20.8zM64 88c0 14.4 3.5 28 9.6 40H32c-17.7 0-32 14.3-32 32v64c0 17.7 14.3 32 32 32H480c17.7 0 32-14.3 32-32V160c0-17.7-14.3-32-32-32H438.4c6.1-12 9.6-25.6 9.6-40c0-48.6-39.4-88-88-88h-2.2c-31.9 0-61.5 16.9-77.7 44.4L256 85.5l-24.1-41C215.7 16.9 186.1 0 154.2 0H152C103.4 0 64 39.4 64 88zm336 0c0 22.1-17.9 40-40 40H288h-1.3l34.8-59.2C329.1 55.9 342.9 48 357.8 48H360c22.1 0 40 17.9 40 40zM32 288V464c0 26.5 21.5 48 48 48H224V288H32zM288 512H432c26.5 0 48-21.5 48-48V288H288V512z"></path>
                                        </svg>Faire un cadeau
                                      </div>
                                      <div class="shop-buy-button">
                                        <svg width="20" height="20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="basket-shopping" class="svg-inline--fa fa-basket-shopping " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" >
                                          <path fill="currentColor" d="M253.3 35.1c6.1-11.8 1.5-26.3-10.2-32.4s-26.3-1.5-32.4 10.2L117.6 192H32c-17.7 0-32 14.3-32 32s14.3 32 32 32L83.9 463.5C91 492 116.6 512 146 512H430c29.4 0 55-20 62.1-48.5L544 256c17.7 0 32-14.3 32-32s-14.3-32-32-32H458.4L365.3 12.9C359.2 1.2 344.7-3.4 332.9 2.7s-16.3 20.6-10.2 32.4L404.3 192H171.7L253.3 35.1zM192 304v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16s16 7.2 16 16zm96-16c8.8 0 16 7.2 16 16v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16zm128 16v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16s16 7.2 16 16z"></path>
                                        </svg>
                                        <span>buy</span>
                                      </div>
                                    </th>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
        `
        $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content").append(content)
    } else if (str == 'daily') {
        togglePrimaryClass("daily-button", "rank-button");
        togglePrimaryClass("daily-button", "weapon-button");
        togglePrimaryClass("daily-button", "myskins-button");

        $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content").empty();

        const content = `
        <div class="category-items">
            <div class="shop-packages-content">
              
            </div>
          </div>
        `

        $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content").append(content)
        
        $.get("https://gamemode/GetDailyShop", function(data) { 
          // console.log(JSON.stringify(data.List))
          $.each(data.List, function(k, v) {
            // console.log(v.type)
            if (v.type == "items") {
              const content = `
               <div class="shop-pkg-container">
                <div class="icon-container">
                  <div class="icon" style="background-image: url(&quot;/ui/assets/items/${v.image}.png&quot;);"></div>
                </div>
                <div class="details-container">
                  <span class="item-name">${v.label}</span>
                  <span class="item-category">${v.Description}</span>
                </div>
                <div class="purchase-container">
                  <div class="purchase-button" onclick="BuyInShop('${v.id}')">
                    <span class="purchase-button-text">${v.price} Tokens</span>
                  </div>
                </div>
              </div>
              `
              $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content .category-items .shop-packages-content").append(content);

            } else if (v.type == "ped") {
              const content = `
              <div class="shop-pkg-container">
               <div class="icon-container">
                 <div class="icon" style="background-image: url(&quot;/ui/assets/shop/packages/${v.model}.webp&quot;);"></div>
               </div>
               <div class="details-container">
                 <span class="item-name">${v.label}</span>
                 <span class="item-category">${v.Description}</span>
               </div>
               <div class="purchase-container">
                 <div class="purchase-button" onclick="BuyInShop('${v.id}')">
                   <span class="purchase-button-text">${v.price} Tokens</span>
                 </div>
               </div>
             </div>
             `
             $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content .category-items .shop-packages-content").append(content);
            }
          });

        });
    } else if (str == 'myskins') {
      togglePrimaryClass("myskins-button", "daily-button");
      togglePrimaryClass("myskins-button", "weapon-button");
      togglePrimaryClass("myskins-button", "rank-button");

      $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content").empty();

      const content = `
        <div class="category-items">
            <div class="shop-packages-content">
              
            </div>
          </div>
        `

      $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content").append(content)

      const freemode = `
              <div class="shop-pkg-container">
               <div class="icon-container">
                 <div class="icon" style="background-image: url(&quot;/ui/assets/shop/packages/mp_m_freemode_01.webp&quot;);"></div>
               </div>
               <div class="details-container">
                 <span class="item-name">Default Skin Male</span>
               </div>
               <div class="purchase-container">
                 <div class="purchase-button" onclick="EquipSkin('mp_m_freemode_01')">
                   <span class="purchase-button-text">Equip the Skin</span>
                 </div>
               </div>
               <div class="purchase-container customize-container">
                <div class="purchase-button" onclick="CustomizeSkin()">
                  <span class="purchase-button-text">Customize the Skin</span>
                  </div>
              </div>
              <div class="purchase-container old-container">
                <div class="purchase-button" onclick="OldSkin()">
                  <span class="purchase-button-text">Put on my old skin</span>
                </div>
              </div>
            </div>
             </div>
             `
             $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content .category-items .shop-packages-content").append(freemode);

        const freemode2 = `
        <div class="shop-pkg-container">
        <div class="icon-container">
          <div class="icon" style="background-image: url(&quot;/ui/assets/shop/packages/mp_f_freemode_01.webp&quot;);"></div>
        </div>
        <div class="details-container">
          <span class="item-name">Default Skin Female</span>
        </div>
        <div class="purchase-container">
          <div class="purchase-button" onclick="EquipSkin('mp_f_freemode_01')">
            <span class="purchase-button-text">Equip the Skin</span>
          </div>
        </div>
        <div class="purchase-container customize-container">
          <div class="purchase-button" onclick="CustomizeSkin()">
            <span class="purchase-button-text">Customize the Skin</span>
          </div>
        </div>
        <div class="purchase-container old-container">
          <div class="purchase-button" onclick="OldSkin()">
            <span class="purchase-button-text">Put on my old skin</span>
          </div>
        </div>
      </div>
      `
      $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content .category-items .shop-packages-content").append(freemode2);

      $.get("https://gamemode/GetMySkins", function(data) {
          console.log(JSON.stringify(data.peds))
          if (data.peds) {
            $.each(data.peds, function(k, v) {
              const content = `
              <div class="shop-pkg-container">
               <div class="icon-container">
                 <div class="icon" style="background-image: url(&quot;/ui/assets/shop/packages/${v.model}.webp&quot;);"></div>
               </div>
               <div class="details-container">
                 <span class="item-name">${v.label}</span>
                 <span class="item-category">${v.Description}</span>
               </div>
               <div class="purchase-container">
                 <div class="purchase-button" onclick="EquipSkin('${v.id}')">
                   <span class="purchase-button-text">Equip the Skin</span>
                 </div>
               </div>
             </div>
             `
             $(".extinction-donator-shop .premium-shop-home .premium-shop-market .shop-content .category-items .shop-packages-content").append(content);
            });
          } else if (data.weapons) {
          
          }
      });

    }
}


function OldSkin() {
  $.post("https://gamemode/OldSkin", JSON.stringify({}), function(data) {
    if (data.status == "success") {
      console.log("success")
    } else {
      console.log("error")
    }
  });
}

function CustomizeSkin() {
  $.post("https://gamemode/Close");
  $.post("https://gamemode/CustomizeSkin", JSON.stringify({}), function(data) {
    if (data.status == "success") {
      console.log("success")
    } else {
      console.log("error")
    }
  });
}
function EquipSkin(id) {
  console.log(id)
  $.post("https://gamemode/EquipSkin", JSON.stringify({id: id}), function(data) {
    if (data.status == "success") {
      console.log("success")
    } else {
      console.log("error")
    }
  });
}

function BuyInShop(id) {
 $.post("https://gamemode/BuyDaily", JSON.stringify({id: id}), function(data) {
   if (data.status == "success") {
     console.log("success")
   } else {
     console.log("error")
   }
 });
} 
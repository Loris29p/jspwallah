window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.type === 'killfeed') {
        console.log("KILLFEED", data.killer, data.weapon, data.victim);
        addKillToFeed(data.killer, "#ffffff", './assets/killfeed/weapons/' + data.weapon + '.png', data.victim, "color-8", data.isRedzone, data.prestige, data.killerPrestige);

    } else if (data.type === 'killfeed_status') {
        console.log("KILLFEED STATUS", data.status);
        StatusKillfeed(data.status);
    }
});


function StatusKillfeed(bool) {
    if (bool) {
        $('.killfeed').css('display', 'flex');
    } else {
        $('.killfeed').css('display', 'none');
    }
}


function addKillToFeed(killer, killerColor, weaponImageUrl, victim, victimColor, isRedzone, prestige, killerPrestige) {
    const killfeed = document.querySelector('.killfeed');
    if (!killfeed) {
        console.error('Killfeed element not found');
        return;
    }

    const maxOrder = 5;

    const order5 = killfeed.querySelector('.kill-card.order-5');
    if (order5) {
        killfeed.removeChild(order5);
    }

    for (let i = maxOrder - 1; i >= 1; i--) {
        const currentCard = killfeed.querySelector(`.kill-card.order-${i}`);
        if (currentCard) {
            currentCard.classList.remove(`order-${i}`);
            currentCard.classList.add(`order-${i + 1}`);
        }
    }

    const backgroundColor = isRedzone ? 'rgba(158, 15, 15, 0.5)' : 'rgba(0, 0, 0, 0.5)';

    const newKillCard = document.createElement('div');
    newKillCard.classList.add('kill-card', 'order-1');

    // Ajouter le badge de prestige pour le killer si killerPrestige > 0
    const killerBadge = killerPrestige > 0
        ? `<div class="game-badge svg-badge kill-badge left">
             <img alt="" src="./assets/badges/prestige_${killerPrestige}.png">
           </div>`
        : '';

    // Ajouter le badge de prestige pour la victime si prestige > 0
    const victimBadge = prestige > 0
        ? `<div class="game-badge svg-badge kill-badge right">
             <img alt="" src="./assets/badges/prestige_${prestige}.png">
           </div>`
        : '';

    newKillCard.innerHTML = `
        <div class="card" style="background-color: ${backgroundColor};">
            ${killerBadge}
            <span class="killer">
                <span class="color" style="color: ${killerColor}">${killer}</span>
            </span>
            <div class="weapon-img">
                <div style="background-image: url('${weaponImageUrl}');"></div>
            </div>
            <span class="victim">
                <span class="color" style="color: ${victimColor}">${victim}</span>
            </span>
            ${victimBadge}
        </div>
    `;

    killfeed.insertBefore(newKillCard, killfeed.firstChild);

    setTimeout(() => {
        newKillCard.classList.add('fade-out');
        setTimeout(() => {
            killfeed.removeChild(newKillCard);
        }, 1000);
    }, 2000);
}
